package com.example.pipe.carrier_manager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.pipe.R;
import com.example.pipe.data.DBGeneralData;
import com.example.pipe.thread.TaskManager;

import java.util.concurrent.Future;

public class BidActivity extends AppCompatActivity  implements View.OnClickListener{
    //Declare Variables for widgets
    TextView tv_location_begin;
    TextView tv_location_end;
    TextView tv_date_limit_transport;
    TextView tv_product;
    TextView tv_quantity;
    TextView tv_comments;
    EditText et_high_price;
    Button btn_cancel;
    Button btn_bid;
    //Private variables
    Boolean bValidate = false;
    private DBGeneralData generalData; //general data loaded when login to app
    private rowBid rowdata;  //where to load o save data to DB
    private float fHighPrice = 0.0f; //bid value
    private String people_id;
    private int auction_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bid);
        //create widget objets
        tv_location_begin = (TextView) findViewById(R.id.bid_tv_location_begin);
        tv_location_end = (TextView) findViewById(R.id.bid_tv_location_end);
        tv_date_limit_transport = (TextView) findViewById(R.id.bid_tv_date_limit_transport);
        tv_product = (TextView) findViewById(R.id.bid_tv_product);
        tv_quantity = (TextView) findViewById(R.id.bid_tv_quantity);
        tv_comments = (TextView) findViewById(R.id.bid_tv_comments);
        et_high_price = (EditText) findViewById(R.id.bid_et_high_price);
        btn_cancel = (Button) findViewById(R.id.bid_btn_cancel);
        btn_bid = (Button) findViewById(R.id.bid_btn_bid);
        //Get Data from previous Intent
        Intent intent = getIntent();
        auction_id = Integer.parseInt(intent.getStringExtra("auction_id"));
        people_id = intent.getStringExtra("people_id");

        tv_location_begin.setText(intent.getStringExtra("location_begin_name"));
        tv_location_end.setText(intent.getStringExtra("location_end_name"));
        tv_date_limit_transport.setText(intent.getStringExtra("date_limit_transport"));
        tv_product.setText(intent.getStringExtra("product_name"));
        tv_quantity.setText(intent.getStringExtra("quantity"));
        tv_comments.setText(intent.getStringExtra("comments"));
        //create an instance of Class rowBid
        rowdata = new rowBid();
        //Set buttons status
        btn_bid.setEnabled(false);
        //Set Listener
        btn_bid.setOnClickListener(this);
        btn_cancel.setOnClickListener(this);
        et_high_price.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }
            //Validate the data high_price, to be a least two digits and max of 6 digits
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                if (charSequence.length() > 2 && charSequence.length() <= 6) {
                    bValidate = true;
                    Validate();
                }
                else
                {
                    bValidate = false;
                    Validate();

                }
            }
            //Only Numeric Integer Values are allowed
            @Override
            public void afterTextChanged(Editable editable) {
                String location_name = editable.toString();
                if (location_name.matches(".*[^0-9].*")) {
                    location_name = location_name.replaceAll("[^0-9]", "");
                    editable.append(location_name);
                    editable.clear();
                    bValidate = false;
                }
                Validate();

            }
        });




    }

    @Override
    public void onClick(View view) {
        //btn_cancel clicked
        if (view == btn_cancel)
        {
            BidActivity.super.onBackPressed();
        }
        //btn_bid clicked: saving data to DB
        if (view == btn_bid)
        {
            //Call SaveData, function to charge of Save data to DB
            SaveData();
        }

    }
    //Function Validate: compares the values in the Intent previous to in the database
    public void Validate()
    {
        if (bValidate)
        {
            btn_bid.setEnabled(true);
        }
        else
        {
            btn_bid.setEnabled(false);
        }

    }
    //Function SaveData: To charge of save the bid in auction_id, DB
    private void SaveData()
    {

        //get data from Current Intent
        fHighPrice = Float.parseFloat(et_high_price.getText().toString());
        //Setup class rowdata to save to DB
        rowdata.setPhpConfig(" bids ", 1); //Setup table and operationType =1, INSERT
        //Set Data in rowdata
        rowdata.setPeople_id(people_id);
        rowdata.setAuction_id(auction_id);
        rowdata.setHigh_price(fHighPrice);
        //Execute task of save to database
        Future future = TaskManager.getTaskManager().forLightWeightBackgroundTasks().submit(rowdata);

        while (!future.isDone() )
        {

        }
        //invoque dlg_exit(); To the previous intent with new data
        dlg_exit();
    }
    //Function dlg_exit: Once the data is saved, go to previous intent with new data and exit the present intent
    private void dlg_exit()
    {
        Intent intent = getIntent();
        rowdata.setHigh_price(fHighPrice);
        intent.putExtra("viewbid", rowdata);//Send RowLocation class to parent objet
        //Finish Intent
        BidActivity.super.setResult(RESULT_OK,intent);
        finish();
    }

}