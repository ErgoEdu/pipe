package com.example.pipe.carrier_manager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.pipe.R;
import com.example.pipe.carrier_manager.placeholder.PlaceholderContent.PlaceholderItem;
import com.example.pipe.data.DBGeneralData;
import com.example.pipe.data.rowViewService;

import java.util.List;

/**
 * {@link RecyclerView.Adapter} that can display a {@link PlaceholderItem}.
 * TODO: Replace the implementation with code for your data type.
 */
public class MypendingRecyclerViewAdapter
        extends RecyclerView.Adapter<MypendingRecyclerViewAdapter.ViewHolder> {
    private DBGeneralData generaldata;
    private final List<rowViewService> mValues;
    private PendingsItemClickListener listener;

    public MypendingRecyclerViewAdapter(List<rowViewService> items, PendingsItemClickListener listener) {
        mValues = items;
        this.listener = listener; // set the listener from fragment to this
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        //  return new ViewHolder(FragmentServicesBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.pending_item, parent, false); //location_item
        generaldata =DBGeneralData.getInstance();
        return new ViewHolder(view);
    }

    // Egonzalez:Interface PendingsItemClickListener
    public interface PendingsItemClickListener
    {
        // Functions of interface
        void onImgButton (int position);
        void onImgButtonChat (int position);
        void onMapButton (int position );

    }
    //End Interface PendingsItemClickListener

    // Egonzalez: Function to get Instance Class according to the position class of mValues Array
    rowViewService getRow(int position)
    {
        rowViewService row;
        row = mValues.get(position);
        return row;

    }
    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        rowViewService row = mValues.get(position); //Row of array base class in the RecyclerView
        if (row == null) return;
        holder.tv_location_begin.setText(row.getLocation_begin_name());
        holder.tv_location_end.setText(row.getLocation_end_name());
        holder.tv_product.setText(row.getProduct_name());
        holder.tv_quantity.setText(Integer.toString(row.getQuantity()));
        String status = row.getStatus();
        String statusName = generaldata.getStatusName(status);
        holder.tv_status.setText(statusName);
            if (status.equals("B") || status.equals("D")){
                holder.img_map.setVisibility(View.VISIBLE);
            }
            else
            {
                holder.img_map.setVisibility(View.INVISIBLE);
            }
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
                implements  View.OnClickListener
    {
        public final View mView;
        public final TextView tv_location_begin;
        public final TextView tv_location_end;
        public final TextView tv_product;
        public final TextView tv_quantity;
        public final TextView tv_status;
        public final ImageView img_button;
        public final ImageView img_chat;
        public final ImageView img_map;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            tv_location_begin
                    = (TextView) view.findViewById(R.id.lv_location_begin);
            tv_location_end
                    = (TextView) view.findViewById(R.id.lv_location_end);
            tv_product
                    = (TextView) view.findViewById(R.id.lv_product);
            tv_quantity
                    = (TextView) view.findViewById(R.id.lv_quantity);

            tv_status
                    = (TextView) view.findViewById(R.id.lv_status);
            img_button
                    = (ImageView) view.findViewById(R.id.lv_button);
            img_chat
                    = (ImageView) view.findViewById(R.id.lv_whatsapp);
            img_map
                    = (ImageView) view.findViewById(R.id.lv_map);

            img_button.setOnClickListener(this);
            img_chat.setOnClickListener(this);
            img_map.setOnClickListener(this);


        }
        @Override
        public String toString() {
            return super.toString() + " '" + tv_location_end.getText() + "'";
        }

        @Override
        public void onClick(View view) {

            int position = getAdapterPosition();
            if (view == img_chat)  // do click in lv_whatsapp
            {
                listener.onImgButtonChat(position);
            }
            if (view == img_button) // do click in lv_button
            {
                listener.onImgButton(position);
            }
            if (view ==  img_map)  // do click in lv_map
            {
                listener.onMapButton(position);
            }

        }
    }
}