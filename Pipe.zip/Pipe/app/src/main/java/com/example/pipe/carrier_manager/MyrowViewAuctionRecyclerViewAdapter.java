package com.example.pipe.carrier_manager;

import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.pipe.R;
import com.example.pipe.carrier_manager.placeholder.PlaceholderContent.PlaceholderItem;
import com.example.pipe.data.rowViewAuction;


import java.util.List;

/**
 * {@link RecyclerView.Adapter} that can display a {@link PlaceholderItem}.
 * TODO: Replace the implementation with code for your data type.
 */
public class MyrowViewAuctionRecyclerViewAdapter extends RecyclerView.Adapter<MyrowViewAuctionRecyclerViewAdapter.ViewHolder> {

    private final List<rowViewAuction> mValues;
    private final ListItemClickListener mOnClickListener;  //internal variable to save listener

    public MyrowViewAuctionRecyclerViewAdapter(List<rowViewAuction> items, ListItemClickListener listener) {
        mValues = items;
        mOnClickListener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        //  return new ViewHolder(FragmentAuctionsBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_item, parent, false); //location_item
        return new ViewHolder(view);
    }

    //EGonzalez: Interface Listener to Callback to the fragment
    public interface ListItemClickListener{
        //DeFine the methods of interface listener
        void onAddBid ( int position);  //Call method to Add Bid to auction
        void onViewRoute ( int position);  //Call method to View Route of auction
    }

    //Egonzalez: Function to get Instance Class according  to the position from classes of mValues Array
    rowViewAuction getRow (int position)
    {
        rowViewAuction row;
        row = mValues.get(position);
        return row;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        rowViewAuction fila = mValues.get(position); //Row of array values class in the RecyclerView
        holder.tv_auction_lv_location_begin.setText(fila.getLocation_begin_name());
        holder.tv_auction_lv_location_end.setText(fila.getLocation_end_name());
        holder.tv_auction_lv_product.setText(fila.getProduct_name());

        holder.tv_auction_lv_quantity.setText(Integer.toString(fila.getQuantity()));
        holder.tv_auction_lv_date_limit_transport.setText(fila.getDate_limit_trasport());
        holder.tv_auction_lv_descripction.setText(fila.getComments());
                if (fila.isWithbid()) { //if the auction have a bid by me
                    holder.ivAddBid.setVisibility(View.INVISIBLE); //Allows to the user to bid whether no have any bid already for the auction
                    String str = "Oferte: S/. " + Float.toString(fila.getHighprice());
                    holder.tv_auction_lv_bid.setText(str);
                    holder.tv_auction_lv_bid.setVisibility(View.VISIBLE);

                }
                else
                {
                    holder.ivAddBid.setVisibility(View.VISIBLE); //Allows to the user to bid whether no have any bid already for the auction
                    holder.tv_auction_lv_bid.setText("");
                    holder.tv_auction_lv_bid.setVisibility(View.INVISIBLE);

                }

    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener {
        public final View mView;
        public final TextView tv_auction_lv_location_begin;
        public final TextView tv_auction_lv_location_end;
        public final TextView tv_auction_lv_product;
        public final TextView tv_auction_lv_quantity;
        public final TextView tv_auction_lv_date_limit_transport;
        public final TextView tv_auction_lv_descripction;
        public final ImageView ivViewRoute; //auction_lv_button_route
        public final ImageView ivAddBid;  //auction_lv_button
        public final TextView tv_auction_lv_bid; //how much i bid for this auction


        public ViewHolder(View view) {
            super(view);
            mView = view;
            tv_auction_lv_location_begin
                    = (TextView) view.findViewById(R.id.auction_lv_location_begin);
            tv_auction_lv_location_end
                    = (TextView) view.findViewById(R.id.auction_lv_location_end);
            tv_auction_lv_product
                    = (TextView) view.findViewById(R.id.auction_lv_product);
            tv_auction_lv_quantity
                    = (TextView) view.findViewById(R.id.auction_lv_quantity);
            tv_auction_lv_date_limit_transport
                    = (TextView) view.findViewById(R.id.auction_lv_date_limit_transport);
            tv_auction_lv_descripction
                    = (TextView) view.findViewById(R.id.auction_lv_description);
            ivViewRoute = (ImageView)  view.findViewById(R.id.auction_lv_button_route);
            ivAddBid = (ImageView)  view.findViewById(R.id.auction_lv_button);
            tv_auction_lv_bid
                    = (TextView) view.findViewById(R.id.auction_lv_bid);

            ivViewRoute.setOnClickListener(this); //set listener to image view view Route
            ivAddBid.setOnClickListener(this); //set listener to image view  add auction
            view.setOnClickListener(this); //set listener to view



        }


        @Override
        public String toString() {
            return super.toString() + " '" + tv_auction_lv_descripction.getText() + "'";
        }

        @Override
        public void onClick(View view) {
            int position = getAdapterPosition();
            if (view.getId() == ivAddBid.getId())
            {
                mOnClickListener.onAddBid(position);
            }
            if (view.getId() == ivViewRoute.getId())
            {
                mOnClickListener.onViewRoute(position);
            }


        }
    }
}