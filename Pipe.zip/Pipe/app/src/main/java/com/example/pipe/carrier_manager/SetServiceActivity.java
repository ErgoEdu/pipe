package com.example.pipe.carrier_manager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.pipe.data.DBGeneralData;
import com.example.pipe.data.rowViewService;
import com.example.pipe.databinding.ActivitySetServiceBinding;
import com.example.pipe.thread.TaskManager;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class SetServiceActivity extends AppCompatActivity {

    private ActivitySetServiceBinding binding;
    //Declare Variables for widgets
    TextView tv_location_begin;
    TextView tv_location_end;
    TextView tv_product;
    TextView tv_quantity;
    TextView tv_status;
    Button btn_back;
    Button btn_set;
    // Declare general variables
    private DBGeneralData generalData;
    private rowViewService rowdata;
    String statusNext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.activity_set_service);
        binding = ActivitySetServiceBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        // set widgets
        tv_location_begin = binding.tvLocationBegin;
        tv_location_end = binding.tvLocationEnd;
        tv_product = binding.tvProduct;
        tv_quantity =binding.tvQuantity;
        tv_status = binding.tvStatus;
        btn_back = binding.btnCancel;
        btn_set = binding.btnSet;
        // get DBGeneralData
        generalData = DBGeneralData.getInstance();
        //get class rowViewService from previous intent
        Intent intent =getIntent();
        rowdata = intent.getParcelableExtra("row");
        if (rowdata == null) finish(); // if no instance of class rowViewService
        SetRowDataToWidgets(); //Assign data from rowdata (class rowViewService) to widgets

        //set listeners
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    finish(); //end activity

            }
        });

        btn_set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SaveData();  // Save Status to DB

            }
        });
        // end set listeners


    }

    private void SetRowDataToWidgets(){
        tv_location_begin.setText(rowdata.getLocation_begin_name());
        tv_location_end.setText(rowdata.getLocation_end_name());
        tv_product.setText(rowdata.getProduct_name());
        tv_quantity.setText(Integer.toString(rowdata.getQuantity()));
        statusNext = generalData.getStatusNext(rowdata.getStatus());
        tv_status.setText(generalData.getStatusName(statusNext));
    }
    //Begin SaveData(): Save status to DB
    private void SaveData()
    {
        //Save to DB
        rowdata.setPhpConfig("service", 2);
        String sWhere = String.format(" id=%d", rowdata.getId());
        String sUpdate = String.format(" status ='%s' ", statusNext);
        rowdata.setStatus(statusNext);
        rowdata.pre_columns = sUpdate;
        rowdata.setWhere(sWhere);
        try {
            Future<Integer> future = TaskManager.getTaskManager().forLightWeightBackgroundTasks().submit(rowdata);
            if (future.get().intValue() == 1){
                Intent intent = getIntent();

                intent.putExtra("row", rowdata);
                //finish Intent
                SetServiceActivity.super.setResult(RESULT_OK,intent);
                finish();  // That is it
            }
        } catch (InterruptedException e) {
            Toast.makeText(this,"@string/err_db", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        } catch (ExecutionException e) {
            Toast.makeText(this,"@string/err_db", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        //End Save to DB


    }
    //End SaveData();
}