package com.example.pipe.carrier_manager;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.example.pipe.R;
import com.google.android.material.tabs.TabLayout;



public class TabCarrierActivity extends AppCompatActivity {

    //Egonzalez private ActivityTabCarrierBinding binding;
    SectionsPagerAdapter1 m_sectionsPagerAdapter;
    private Fragment fragment;  //egonzalez fragment active
    rowViewAuctionFragment fragment_local; //egonzalez
    private ViewPager viewPager; //egonzalez

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Egonzalez binding = ActivityTabCarrierBinding.inflate(getLayoutInflater());
        setContentView(R.layout.activity_tab_carrier);

        m_sectionsPagerAdapter= new SectionsPagerAdapter1(this, getSupportFragmentManager());
        viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(m_sectionsPagerAdapter);

        TabLayout tabs = findViewById(R.id.tabs); //chequar
        tabs.setupWithViewPager(viewPager);
       /* FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/
    }
}