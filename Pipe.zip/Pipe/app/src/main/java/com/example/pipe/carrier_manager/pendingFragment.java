package com.example.pipe.carrier_manager;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pipe.R;
import com.example.pipe.data.DBGeneralData;
import com.example.pipe.data.rowViewService;
import com.google.android.gms.maps.model.LatLng;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

/**
 * A fragment representing a list of Items.
 */
public class pendingFragment extends Fragment
implements MypendingRecyclerViewAdapter.PendingsItemClickListener
{

    // TODO: Customize parameter argument names
    private static final String ARG_COLUMN_COUNT = "column-count";
    // TODO: Customize parameters
    private int mColumnCount = 1;

    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    //local variables
    MypendingRecyclerViewAdapter adapter; //recycler view mypending services
    ArrayList<rowViewService> list;  // where the data is stored
    private DBGeneralData generaldata;
    rowViewService row; // instance where is stored class rowViewService from array list
    int currentPosition = 0; // store the currentPosition of list in recyclerview
    RecyclerView r;  // recyclerview of fragment
    public pendingFragment() {
    }

    // TODO: Customize parameter initialization
    @SuppressWarnings("unused")
    public static pendingFragment newInstance(int columnCount) {
        pendingFragment fragment = new pendingFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_COLUMN_COUNT, columnCount);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.pending_item_list, container, false);

        // Set the adapter
        r=(RecyclerView) view.findViewById(R.id.list);
        // Set the adapter
        if (r instanceof RecyclerView) {  //30 if (view instanceof RecyclerView) {
            //30Context context = view.getContext();
            Context context  =r.getContext();
            //30 RecyclerView recyclerView = (RecyclerView) view;
            // Egonzalez: set adapter
            generaldata = DBGeneralData.getInstance();  // Get General Data class singleton of App
            // Call getPendingServices, where is show all my services pendings
            if (generaldata.getPendingServices()){
                list =generaldata.list_pendings; // get the fill-up array of my services
            }
            else
            {
                list = new ArrayList<rowViewService>();
            }
            // Egonzalez: Set adapter
            adapter = new MypendingRecyclerViewAdapter(list, this);  //set the  values o list to adapter contructor
            r.setAdapter(adapter);  //set the local adapter to reciclerview
            // set Layout manager to position the items
            r.setLayoutManager(new LinearLayoutManager(context));
        }
        return view;
    }
    // function to open status update Intent: SetServiceActivity
    @Override
    public void onImgButton(int position) {
        row = adapter.getRow(position);
        currentPosition = position;
        if (row != null) // Start to open SetServiceActivity
        {
            mStartSetServiceActivity.launch(3);
        }


    }

    @Override
    public void onImgButtonChat(int position) {
//Open dialog chat with the class instance from rowViewService
        rowViewService row = adapter.getRow(position);

        if (row != null){
            //Open Intent to open whatsapp
            String phone = row.getCustomer_contact();
            if (phone.equals("") || phone == null) return;
            //Begin WhatsApp Code
            String number = phone.contains("+") ? phone : "+51" + phone; // set default number for Peru
            String mensaje = "Deseo coordinar con usted el transporte pendiente";
          /*  Uri uri = Uri.parse("smsto:" + number);
            Intent i = new Intent(Intent.ACTION_SENDTO, uri);
            i.setPackage("com.whatsapp");
            String msg = "Deseo coordinar con usted el transporte pendiente";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=" + number + "&text=" + msg)));
            // End WhatsApp Code
            */
            //Code Copied from
            try{

                String url = "https://api.whatsapp.com/send?phone="+ number +"&text=" + mensaje;
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                this.startActivity(i);

            }catch(Exception e) {
                Log.e("ERROR WHATSAPP",e.toString());
                Toast.makeText(getActivity(), "No tiene whatsapp instalado!",Toast.LENGTH_SHORT).show();
            }
        }

    }

    @Override
    public void onMapButton(int position) {
        rowViewService row = adapter.getRow(position);
        LatLng location_from;
        LatLng location_to;
        int iFrom = row.getLocation_begin();
        int iTo = row.getLocation_end();
        if (row != null)
        {
            String status = row.getStatus();
            if (status.equals("B")) {

                generaldata.openMapLocation(getContext(), -1, iFrom);
            }
            if (status.equals("D")) {

                generaldata.openMapLocation(getContext(), iFrom, iTo);
            }

        }
    }

    //PickService: Activity Contract to call SetServiceActivity
    public class PickService extends ActivityResultContract<Integer,rowViewService> {

        @NonNull
        @NotNull
        @Override
        public Intent createIntent(@NonNull @NotNull Context context, Integer input) {
            Intent intent = new Intent(context, SetServiceActivity.class);
            intent.putExtra("EXTRA_INT", input);
            if (row != null){
                intent.putExtra("row", row);
            }
            return intent;
        }

        @Override
        public rowViewService parseResult(int resultCode, @Nullable @org.jetbrains.annotations.Nullable Intent intent) {
            if (resultCode != Activity.RESULT_OK || intent == null) {
                return null;
            }
            return intent.getParcelableExtra("row");
        }
    }
    //End PickService
    // Star Launcher mStartSetServiceActivity  (Open SetServiceActivity Intent)
    private final ActivityResultLauncher<Integer> mStartSetServiceActivity =
            registerForActivityResult(new PickService(),
                    new ActivityResultCallback<rowViewService>() {
                        @Override
                        public void onActivityResult(rowViewService result) {
                            if (result !=null)
                            {
                                row.setStatus(result.getStatus());
                                adapter.notifyItemChanged(currentPosition);
                                r.scrollToPosition(currentPosition);
                            }
                        }
                    });
    // End Launcher mStartSetServiceActivity
}