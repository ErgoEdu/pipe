package com.example.pipe.carrier_manager;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.Nullable;

import com.example.pipe.thread.DBTask;

/* Egonzalez Class rowBid
to accessing row data from DB: Table=bids */

public class rowBid extends DBTask implements Parcelable {
    protected int auction_id;
    protected String people_id;
    protected float low_price;
    protected float high_price;
    protected float preferred_price;
    protected String comments;
    protected String status;

    protected rowBid(Parcel in) {
        auction_id = in.readInt();
        people_id = in.readString();
        low_price = in.readFloat();
        high_price = in.readFloat();
        preferred_price = in.readFloat();
        comments = in.readString();
        status = in.readString();
    }

    public static final Creator<rowBid> CREATOR = new Creator<rowBid>() {
        @Override
        public rowBid createFromParcel(Parcel in) {
            return new rowBid(in);
        }

        @Override
        public rowBid[] newArray(int size) {
            return new rowBid[size];
        }
    };

    public int getAuction_id() {
        return auction_id;
    }

    public void setAuction_id(int auction_id) {
        addParam("auction_id",auction_id);
        this.auction_id = auction_id;
    }

    public String getPeople_id() {

        return people_id;
    }

    public void setPeople_id(String people_id) {
        addParam("people_id",people_id);

        this.people_id = people_id;
    }

    public float getLow_price() {
        return low_price;
    }

    public void setLow_price(float low_price) {
        addParam("low_price",low_price);

        this.low_price = low_price;
    }

    public float getHigh_price() {
        return high_price;
    }

    public void setHigh_price(float high_price) {
        addParam("high_price",high_price);

        this.high_price = high_price;
    }

    public float getPreferred_price() {
        return preferred_price;
    }

    public void setPreferred_price(float preferred_price) {
        addParam("preferred_price",preferred_price);

        this.preferred_price = preferred_price;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        addParam("comments",comments);
        this.comments = comments;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        addParam("status",status);
        this.status = status;
    }

    //Main Constructor
    public rowBid (){
        super();
    }

    @Override
    public void GetRow(int rowPosition, String keyName, String keyValue) {
        switch (keyName) {
            case "auction_id":
                auction_id = Integer.parseInt(keyValue);
                break;
            case "people_id":
                people_id = keyValue;
                break;
            case "low_price":
                low_price = Float.parseFloat(keyValue);
                break;
            case "high_price":
                high_price = Float.parseFloat(keyValue);
                break;
            case "preferred_price":
                preferred_price = Float.parseFloat(keyValue);
                break;
            case "comments":
                comments = keyValue;
                break;
            case "status":
                status = keyValue;
                break;
    }
    }

    @Override
    public void BeginRow() {

    }

    @Override
    public void EndRow() {

    }

    @Override
    public String toString() {
        // return super.toString();
        return status;
    }

    @Override
    public boolean equals(@Nullable @org.jetbrains.annotations.Nullable Object obj) {
        //return super.equals(obj);
        if (obj instanceof rowBid) {
            rowBid c = (rowBid) obj;
            if (c.people_id == people_id && c.auction_id == auction_id);
            return true;
        }
        return false;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(auction_id);
        parcel.writeString(people_id);
        parcel.writeFloat(low_price);
        parcel.writeFloat(high_price);
        parcel.writeFloat(preferred_price);
        parcel.writeString(comments);
        parcel.writeString(status);
    }
}
