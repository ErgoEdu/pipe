package com.example.pipe.carrier_manager;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.pipe.R;
import com.example.pipe.data.DBGeneralData;
import com.example.pipe.data.dataViewAuction;
import com.example.pipe.data.rowViewAuction;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

/**
 * A fragment representing a list of Items.
 */
public class rowViewAuctionFragment extends Fragment implements MyrowViewAuctionRecyclerViewAdapter.ListItemClickListener {

    // TODO: Customize parameter argument names
    private static final String ARG_COLUMN_COUNT = "column-count";
    // TODO: Customize parameters
    private int mColumnCount = 1;

    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    MyrowViewAuctionRecyclerViewAdapter adapter; //Egonzalez: adapter of Auctions recycleview
    ArrayList<rowViewAuction> list; //array where be stored the results of viewcervice
    dataViewAuction data;  //data from database, management of querys and php service to get data from app database
    private DBGeneralData generalData; //general data loaded when login to app
    RecyclerView recyclerView;
    rowViewAuction rowviewauction;  //instance of rowViewAuction
    int rowviewauctionPosition = 0; //Position of the item selected to Bid
    public rowViewAuctionFragment() {
    }

    // TODO: Customize parameter initialization
    @SuppressWarnings("unused")
    public static rowViewAuctionFragment newInstance(int columnCount) {
        rowViewAuctionFragment fragment = new rowViewAuctionFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_COLUMN_COUNT, columnCount);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_item_list, container, false);

        // Set the adapter
        if (view instanceof RecyclerView) {
            Context context = view.getContext();
            recyclerView = (RecyclerView) view;

            //Egonzalez: set adapter, FILL-UP DATA
            generalData = DBGeneralData.getInstance();
            //Call getOpenAuctions, where is showe all the auctions with status ='O' Open in database
            if (generalData.getOpenAuctions()) {
                list = generalData.list_auctions;  //set and  fill up with data of database,
            }
            //Open the data with my bids
            if (generalData.getMyBids()){

                for (rowViewAuction a : list){
                    {
                        for (rowBid b : generalData.list_mybids) {
                            if (a.getId() == b.getAuction_id())
                                a.setWithbid(true);
                                a.setHighPrice(b.getHigh_price());
                        }
                    }
                }

            }

            //FILL-UP DATA endend
            //Egonzalez: set adapter
            adapter = new MyrowViewAuctionRecyclerViewAdapter(list, this);  //set the  values o list to adapter contructor

            recyclerView.setAdapter(adapter);
            //Set Layout manager to position the items
            recyclerView.setLayoutManager(new LinearLayoutManager(context));


        }
        return view;
    }

    //Called by adapter when is pressed the ImageView auction_lv_button item
    @Override
    public void onAddBid(int position) {
        rowviewauction = adapter.getRow(position);
        rowviewauctionPosition = position;  //get position index in list mvalues of rowViewAuctionFragment to add Bid
        //Open Intent where the user gonna bid
        if (rowviewauction != null) {
            mStartBidActivity.launch(3);  //ejecutes routine to Laucher Intent BidActivity

        }

    }

    //Called by adapter when is pressed the ImageView auction_lv_button_route item
    @Override
    public void onViewRoute(int position) {
        rowviewauction = adapter.getRow(position);
        //Open Intent where the user gonna view the route of Auction Requisition
        if (rowviewauction != null) {
        }
    }

    //PickBid: ActivityContract to call BidActivity
    public class PickBid extends ActivityResultContract<Integer, rowBid> {

        @NonNull
        @NotNull
        @Override
        public Intent createIntent(@NonNull @NotNull Context context, Integer input) {
            Intent intent = new Intent(context, BidActivity.class);
            intent.putExtra("EXTRA_INT", input);
            if (rowviewauction != null)
            {
                String people_id = generalData.getPeople_id();
                intent.putExtra("auction_id",Integer.toString(rowviewauction.getId()));
                intent.putExtra("people_id", people_id);

                intent.putExtra("location_begin_name",rowviewauction.getLocation_begin_name());
                intent.putExtra("location_end_name",rowviewauction.getLocation_end_name());
                intent.putExtra("date_limit_transport",rowviewauction.getDate_limit_trasport());//check
                intent.putExtra("product_name",rowviewauction.getProduct_name());
                intent.putExtra("quantity",Integer.toString(rowviewauction.getQuantity())); //check
                intent.putExtra("comments",rowviewauction.getComments());
            }

            return intent;
        }

        @Override
        public rowBid parseResult(int resultCode, @Nullable @org.jetbrains.annotations.Nullable Intent intent) {
            if (resultCode != Activity.RESULT_OK || intent == null) {
                return null;
            }
            return intent.getParcelableExtra("viewbid");  //Get Data name or class from Intent
        }
    }

    private final ActivityResultLauncher<Integer> mStartBidActivity =
            registerForActivityResult( new PickBid(),
                    new ActivityResultCallback<rowBid>(){

                        @Override
                        public void onActivityResult(rowBid result) {
                            if (result !=null)
                            {
                                //add new bid to matrix mybids
                                generalData.list_mybids.add(result);
//                                int n = adapter.getItemCount();
  //                              list.add(result);
    //                            int i = list.size();
                                rowviewauction.setHighPrice(result.getHigh_price());
                                rowviewauction.setWithbid(true);
                                adapter.notifyItemChanged(rowviewauctionPosition);
                                recyclerView.scrollToPosition(rowviewauctionPosition);
                            }
                        }
                    });

}