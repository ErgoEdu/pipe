package com.example.pipe.customer;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.pipe.R;
import com.example.pipe.data.rowViewAuction;
import com.example.pipe.customer.PlaceholderContent.PlaceholderItem;

import java.util.List;

/**
 * {@link RecyclerView.Adapter} that can display a {@link PlaceholderItem}.
 * TODO: Replace the implementation with code for your data type.
 */
public class AuctionsRecyclerViewAdapter extends RecyclerView.Adapter<AuctionsRecyclerViewAdapter.ViewHolder> {

    private final List<rowViewAuction> mValues;

    public AuctionsRecyclerViewAdapter(List<rowViewAuction> items) {
        mValues = items;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

      //  return new ViewHolder(FragmentAuctionsBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_auctions, parent, false); //location_item
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        rowViewAuction fila = mValues.get(position); //Row of array values class in the RecyclerView
        holder.tv_auction_lv_location_begin.setText(fila.getLocation_begin_name());
        holder.tv_auction_lv_location_end.setText(fila.getLocation_end_name());
        holder.tv_auction_lv_product.setText(fila.getProduct_name());

        holder.tv_auction_lv_quantity.setText(Integer.toString(fila.getQuantity()));
        holder.tv_auction_lv_date_limit_transport.setText(fila.getDate_limit_trasport());
        holder.tv_auction_lv_descripction.setText(fila.getComments());
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final TextView tv_auction_lv_location_begin;
        public final TextView tv_auction_lv_location_end;
        public final TextView tv_auction_lv_product;
        public final TextView tv_auction_lv_quantity;
        public final TextView tv_auction_lv_date_limit_transport;
        public final TextView tv_auction_lv_descripction;
        public final ImageView img_auction_lv_button;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            tv_auction_lv_location_begin
                    = (TextView) view.findViewById(R.id.auction_lv_location_begin);
            tv_auction_lv_location_end
                    = (TextView) view.findViewById(R.id.auction_lv_location_end);
            tv_auction_lv_product
                    = (TextView) view.findViewById(R.id.auction_lv_product);
            tv_auction_lv_quantity
                    = (TextView) view.findViewById(R.id.auction_lv_quantity);
            tv_auction_lv_date_limit_transport
                    = (TextView) view.findViewById(R.id.auction_lv_date_limit_transport);
            tv_auction_lv_descripction
                    = (TextView) view.findViewById(R.id.auction_lv_description);
            img_auction_lv_button
                    = (ImageView) view.findViewById(R.id.auction_lv_button);



        }

        @Override
        public String toString() {
            return super.toString() + " '" + tv_auction_lv_descripction.getText() + "'";
        }
    }
}