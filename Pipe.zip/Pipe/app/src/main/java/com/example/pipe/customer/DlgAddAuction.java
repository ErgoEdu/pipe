package com.example.pipe.customer;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.pipe.R;
import com.example.pipe.data.DBGeneralData;
import com.example.pipe.data.Product;
import com.example.pipe.data.RowLocation;
import com.example.pipe.data.rowViewAuction;
import com.example.pipe.thread.TaskManager;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.Future;


/*
Created By: Egonzalez
Creation Date: 13-12-2021
DlgAddAuction: Activity to Add new Auction to Database
This Activity is only por Customer to create an auction available to all transporters
Save the Data in table :auctions
*/



public class DlgAddAuction extends AppCompatActivity implements View.OnClickListener {
    //widgets to save field data
    private Spinner spn_products;  //Spinner widget where to load products
    private Spinner spn_location_begin;  //Spinner widget where to load locations_begin
    private EditText et_date_limit; //EditText for date_limit_transport field in DB, widget dlg_add_et_date
    private TextView tv_location_end; //Text widget where is saved the location name destiny
    private EditText et_quantity;  //Text widget where quantity data is input
    private EditText et_comments;  //Text widget where comments data is input

    private boolean  bValidate [] = new boolean [4]; //variable to set validate values to be true , with datelimit, quantity, location_end

    //variables
    private DatePickerDialog dateLimitPickerDialog;
    private SimpleDateFormat dateFormatter;
    private Button btn_cancel; //widget button to cancel intent
    private Button btn_save; //widget button to call procedure to save data
    private Button btn_hacia; //widger button to show locations intent
    private DBGeneralData generalData; //general data loaded when login to app
    private rowViewAuction rowdata;  //where to load o save data to DB



    //Fields for save data to database
    String sPeopleIdCustomer = "";
    Date dDate_Limit_Transport; //date_limit_transport
    int iProduct = 0; //Product Code
    int iQuantity = 0; //quantity
    int iLocationBegin = 0; //Code of location_begin
    int iLocationEnd = 0;
    String sDescription = ""; //description
    String sComments = ""; //comments
    String sProduct_name = ""; //save name of product
    String sLocation_Begin = ""; //save location_begin
    String sLocation_end = ""; //save location_end
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_dlg_add_auction);
            //get instance of widgets
            generalData = DBGeneralData.getInstance();  //get instance of Singleton class DBGeneralData
            dateFormatter = new SimpleDateFormat("dd-MM-yyyy", Locale.US); //format date local
            spn_products = (Spinner) findViewById(R.id.dlg_add_spn_product);
            spn_location_begin = (Spinner) findViewById(R.id.dlg_add_spn_location_begin);
            tv_location_end = (TextView) findViewById(R.id.dlgadd_tv_location_end);
            et_date_limit = (EditText) findViewById(R.id.dlgadd_et_date_limit);
            et_date_limit.setInputType(InputType.TYPE_NULL);

            et_date_limit.requestFocus();
            rowdata = new rowViewAuction();
            //  rowdata.setCallBack(this);

            setDateTimeField();
            // et_date_limit .setText(sFechaSelected);
            btn_cancel = (Button) findViewById(R.id.dlgadd_btn_cancel);
            btn_save = (Button) findViewById(R.id.dlgadd_btn_save);
            btn_hacia = (Button) findViewById(R.id.dlgadd_btn_hacia);
            btn_cancel.setOnClickListener(this);
            btn_save.setOnClickListener(this);
            btn_hacia.setOnClickListener(this);
            et_quantity = (EditText) findViewById(R.id.dlgadd_et_quantity);
            et_comments = (EditText) findViewById(R.id.dlg_add_et_comments);
            et_comments.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    if (charSequence.length() > 0 && charSequence.length() <= 254) {
                        bValidate[3] = true;
                        Validate();
                    }
                    else
                    {
                        bValidate[3] = false;
                        Validate();

                    }
                }

                @Override
                public void afterTextChanged(Editable editable) {

                }
            });
            et_quantity.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    if (charSequence.length() > 2 && charSequence.length() <= 6) {
                            bValidate[1] = true;
                            Validate();
                    }
                    else
                    {
                        bValidate[1] = false;
                        Validate();

                    }

                }

                @Override
                public void afterTextChanged(Editable editable) {
                    //Validate to admit only 0-9 numbers
                    String location_name = editable.toString();
                    if (location_name.matches(".*[^0-9].*")) {
                        location_name = location_name.replaceAll("[^0-9]", "");
                        editable.append(location_name);

                        editable.clear();
                        bValidate[1] = false;

                        //Toast.makeText(getApplicationContext(),"Solo se permiten enteros!",Toast.LENGTH_SHORT).show();

                    }


                    Validate();

                }
            });

            //fill spinners
            //Fill spn_location_begin with data from table locations
            ArrayAdapter<RowLocation> adapter = new ArrayAdapter<RowLocation>(this,
                    android.R.layout.simple_spinner_dropdown_item, generalData.m_locations.locationsList);
            // adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spn_location_begin.setAdapter(adapter);

            spn_location_begin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    RowLocation location = (RowLocation) adapterView.getSelectedItem();
                    sLocation_Begin = location.getAddress();
                    iLocationBegin = location.getId();


                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {

                }

            });
            //Begin: spn_products , fill up with data from table products
            ArrayAdapter<Product> adapterProduct = new ArrayAdapter<Product>(this,
                    android.R.layout.simple_spinner_dropdown_item, generalData.m_products.datos);
            spn_products.setAdapter(adapterProduct);
            spn_products.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    Product product = (Product) adapterView.getSelectedItem();
                    iProduct = product.id;
                    sProduct_name = product.cname;
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {

                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }//END OnCreate

    @Override
    public void onClick(View view) {
        if (view == et_date_limit)
            dateLimitPickerDialog.show();
        if (view == btn_cancel)  //code to cancel activity
            DlgAddAuction.super.onBackPressed();
        if (view == btn_save)//Save data of intent into database
        {
            SaveData();
        }
        if (view == btn_hacia)  //when the user click EditText et_location_end
        {
            //Call the dialog intent DlgLocation o view location to arrive
            mStartDlgLocation.launch(3); //Call ActivityResultLauncher for Start DlgLocation Intent, the number 3 is arbitrary
        }


    }


    private void setDateTimeField() {
        et_date_limit.setOnClickListener(this);

        Calendar newCalendar = Calendar.getInstance();
        dateLimitPickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Date date_selected;
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                //dDate_Limit_Transport = newDate.getTime();
                date_selected = newDate.getTime();
                Date currentTime = Calendar.getInstance().getTime();

                if (date_selected.compareTo(currentTime) >= 0)
                {
                    String sFechaSelected = dateFormatter.format(newDate.getTime());
                    dDate_Limit_Transport = date_selected;
                    et_date_limit.setText(sFechaSelected);
                    bValidate[0] = true;

                }
                else
                {
                    et_date_limit.setText("");
                    bValidate[0] = false;

                }

                Validate(); //Validate Form

            }

        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));

    }


    //Save Data of Current Intent to database
    //
    private void SaveData() {
        //setup rowViewAuction to get php file and save data to DB
        rowdata.setPhpConfig("sp_insert_view_auction", 5);
        rowdata.setDbPhpFile("execute_sp_insert_view_auction.php");
        //        //get data Values to INSERT INTO database
        rowdata.setProduct(iProduct);  //product_id
        rowdata.setDate_limit_transport(dDate_Limit_Transport); //date_limit_transport
        //get comments from et_comments
        sComments = et_comments.getText().toString();
        rowdata.setComments(sComments); //comments
        rowdata.setPeople_id_customer(generalData.getPeople_id()); //people_id_customer
        rowdata.setLocation_begin(iLocationBegin);  //Set location_begin
        rowdata.setLocation_end(iLocationEnd);  //Set location_end
        //get quantity
        iQuantity = Integer.parseInt(et_quantity.getText().toString());
        rowdata.setQuantity(iQuantity); //Set quantity
        //Construct description
        String str =  et_quantity.getText() + " gal," + sLocation_Begin + "," + sLocation_end;
        sDescription = str.length() > 254 ? str.substring(0,254): str;
        rowdata.setDescription(sDescription);


//        TaskManager.getTaskManager().forLightWeightBackgroundTasks().execute(rowdata);
        Future future = TaskManager.getTaskManager().forLightWeightBackgroundTasks().submit(rowdata);

        while (!future.isDone() )
        {

        }
        dlg_exit(); //Exit of dlgLocation

    }
    //PickAddress Class: Set Contract to Open Address Intent selector (DlgLocation)

    public class PickAddress extends ActivityResultContract<Integer, RowLocation> {

        @NonNull
        @Override
        public Intent createIntent(@NonNull Context context, Integer input) {
            Intent intent = new Intent(context, DlgLocation.class);
            RowLocation location = (RowLocation) spn_location_begin.getSelectedItem();
            String location_begin = "";
            if (location != null) location_begin = location.getAddress();
            intent.putExtra("location_begin", location_begin);
            intent.putExtra("lat_begin",location.getLat_coord()); //Add Latitude to Child Intent
            intent.putExtra("lng_begin",location.getLong_coord()); //Add Longitude to Child Intent
            intent.putExtra("EXTRA_INT", input);

            return intent;
        }

        @Override
        public RowLocation parseResult(int resultCode, Intent intent) {
            if (resultCode != Activity.RESULT_OK || intent == null) {
                return null;
            }
            return intent.getParcelableExtra("location");  //Get Data name or class from Intent
        }
    };

//End Class PickAddress

//Load DlgLocationActivity without contract, and gets result once address is selected

    private final ActivityResultLauncher<Integer> mStartDlgLocation =
            registerForActivityResult( new PickAddress(),
                    new ActivityResultCallback<RowLocation>() {

                        @Override
                        public void onActivityResult(RowLocation result) {
                                if (result != null)
                                {
                                    iLocationEnd = result.getId();
                                    sLocation_end = result.getAddress();
                                    tv_location_end.setText(sLocation_end);
                                    if (iLocationEnd>0)
                                    {
                                        bValidate[2] =true;
                                    }
                                    else
                                    {
                                        bValidate[2] = false;
                                    }
                                    Validate();

                                }

                        }

                    });
    //function called when save data is done
    private void dlg_exit()
    {
        Intent intent = getIntent();
        rowdata.setProduct_name(sProduct_name);
        rowdata.setLocation_begin_name(sLocation_Begin);
        rowdata.setLocation_end_name(sLocation_end);
        intent.putExtra("viewauction", rowdata);//Send RowLocation class to parent objet
        //Finish Intent
        DlgAddAuction.super.setResult(RESULT_OK,intent);
        finish();



    }
    //function to resume validate of the fields date_limit_transport, quantity, location_end
    private void Validate()
    {
        if (bValidate[0] && bValidate[1] && bValidate[2] && bValidate[3])
        {
            btn_save.setEnabled(true);

        }
        else
        {
            btn_save.setEnabled(false);

        }
    }
}//END OF DlgAddAction.java

