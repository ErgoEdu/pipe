package com.example.pipe.customer;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pipe.R;
import com.example.pipe.data.RowLocation;
import com.example.pipe.thread.TaskManager;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

public class DlgLocation extends AppCompatActivity implements View.OnClickListener, LocationsAdapter.ListItemClickListener {
    private Button btn_search;  //Widget, button for search locations in google
    private Button btn_add;  //Widget, button for add selected location to database
    private TextView tv_location_begin2;
    private EditText et_location_end;
    private double lat_begin;
    private double lng_begin;
    private int nlocation_selected = -1; //variable where set the location selected in
    ArrayList<Address> addressList; //array where be stored the results of google address
    RowLocation rowlocation;  //class rowlocation, where DB operations ocurrs
    String strLocationEnd;
    LocationsAdapter locAdapter; //adapter of recycleview
    private ProgressBar mLoadingIndicator;  //widget loading indicator
    Geocoder gc; //Geocoder variable
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dlg_location);
        btn_search = (Button) findViewById(R.id.dlglocation_btn_search);
        btn_search.setOnClickListener(this);
        btn_add= (Button) findViewById(R.id.dlglocation_btn_add);
        btn_add.setOnClickListener(this);
        mLoadingIndicator=(ProgressBar) findViewById(R.id.dlgLocation_loading_indicator);//set variable for loading indicator

        et_location_end = (EditText) findViewById(R.id.dlglocation_et_location_end);
        tv_location_begin2 = (TextView) findViewById(R.id.dlglocation_tv_location_begin2);

        // BEGIN-------------------Code for RecyclerView
        // lookup the recyclerview in activity_dlg_locaction.xml
       addressList= new ArrayList<Address>();
        RecyclerView rvLocationList = (RecyclerView) findViewById(R.id.dlglocation_rv_list);
        // Create adapter passing in the Array addressList
        locAdapter = new LocationsAdapter(addressList,this);
        // Attach the adapter to the reciclerview to populate items
        rvLocationList.setAdapter(locAdapter);
        //configure rowlocation
        rowlocation = new RowLocation();

        // Set Layout manager to position the items
       rvLocationList.setLayoutManager(new LinearLayoutManager(this));
       //get amd set data to tv_location_begin2 from parent Intent
        Intent intent = getIntent();
        String location_begin = intent.getStringExtra("location_begin");
        lat_begin = intent.getDoubleExtra("lat_begin", 0.0f);
        lng_begin = intent.getDoubleExtra("lng_begin", 0.0f);
        tv_location_begin2.setText(location_begin);


    }

    @Override
    public void onClick(View view) {
        if (view == btn_search)  //code to search , where the magic begins
        {
           // mLoadingIndicator.setVisibility(View.VISIBLE);
            strLocationEnd  = et_location_end.getText().toString();
            Geocoder gc= new Geocoder(this);

            try {
               List<Address> newItems = gc.getFromLocationName(strLocationEnd,10);
              //  newItems =  gc.getFromLocationName(strLocationEnd,10);
                if (newItems == null || newItems.isEmpty())
                {
                    btn_add.setEnabled(false);
                    Toast.makeText(this, "No se encontraron resultados!", Toast.LENGTH_SHORT).show();
                }
                if (locAdapter != null) {
                    //locAdapter.notifyDataSetChanged();

                    //int curSize = locAdapter.getItemCount();
                    addressList.clear();
                    addressList.addAll(newItems);
                    // curSize should represent the first element that got added
                    // newItems.size() represents the itemCount
                  // locAdapter.notifyItemRangeInserted(curSize, newItems.size());
                    locAdapter.notifyDataSetChanged();


                }
            } catch (IOException e) {
                e.printStackTrace();
            }
          //  mLoadingIndicator.setVisibility(View.INVISIBLE);




        }
        //if is called button btn_add
        if (view == btn_add)
        {
            SaveLocation();  //Call function to save in DB
        }
    }


    @Override
    public void onImgItemView(int position) {
        //see details of map about the address
        if (position >= 0) {
            Address location = addressList.get(position);
            double latitude = location.getLatitude();
            double longitude = location.getLongitude();
            int i = location.getMaxAddressLineIndex();
            String marker = location.getAddressLine(i);
            /*
            //Call Intent Google Map
            Class destinationActivity = MapsActivity.class;
            Intent startChildActivityIntent = new Intent(this, destinationActivity);
            startChildActivityIntent.putExtra("latitude",latitude); //Add Latitude to Child Intent
            startChildActivityIntent.putExtra("longitude",longitude); //Add Longitude to Child Intent
            startChildActivityIntent.putExtra("marker",marker); //Add marker to Child Intent
            startActivity(startChildActivityIntent);*/
            //Open Maps

            String uri = String.format("http://maps.google.com/maps?saddr=%f,%f&daddr=%f,%f (%s)",lat_begin, lng_begin,latitude,longitude, marker) ;
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
            intent.setPackage("com.google.android.apps.maps");
            try
            {
                startActivity(intent);
            }
            catch(ActivityNotFoundException ex)
            {
                try
                {
                    Intent unrestrictedIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                    startActivity(unrestrictedIntent);
                }
                catch(ActivityNotFoundException innerEx)
                {
                    Toast.makeText(this, "Please install a maps application", Toast.LENGTH_LONG).show();
                }
            }
            //End Open Maps


        }
    }

    @Override
    public void onTvItemAddress(int position) {
            nlocation_selected = position;
            btn_add.setEnabled(true);
    }


    //SaveLocation Function: Store data from present Intent to database, invoque sp= sp_insert_location
    public void SaveLocation()
    {
       // ArrayList<Address> addressList;
        Address location;
        if (nlocation_selected >= 0) { // a location in recycler view  is selected
            location = addressList.get(nlocation_selected);
            int i = location.getMaxAddressLineIndex();
           // String marker = location.getAddressLine(i);
            //Toast.makeText(getApplicationContext(),marker, Toast.LENGTH_SHORT).show();
            rowlocation.setPhpConfig("sp_insert_location",5);
            rowlocation.setDbPhpFile("execute_sp_insert_location.php");
            rowlocation.setAddress(location.getAddressLine(i));
            rowlocation.setLat_coord(location.getLatitude());
            rowlocation.setLong_coord(location.getLongitude());
            rowlocation.setPostalcode(location.getPostalCode());
            rowlocation.setSubadminarea(location.getSubAdminArea());
            rowlocation.setSublocality(location.getSubLocality());
            rowlocation.setAdminarea(location.getAdminArea());
           Future future = TaskManager.getTaskManager().forLightWeightBackgroundTasks().submit(rowlocation);

            while (!future.isDone() )
            {

            }
            dlg_exit(); //Exit of dlgLocation


        }
        else
        {
            Toast.makeText(getApplicationContext(), "Por favor seleccionar una ubicacion!", Toast.LENGTH_SHORT).show();
        }
    }


    public void dlg_exit()
    {
        //   Toast.makeText(getApplicationContext(),marker, Toast.LENGTH_SHORT).show();
        Intent intent = getIntent();
        intent.putExtra("location", rowlocation);//Send RowLocation class to parent objet
        //Finish Intent
        DlgLocation.super.setResult(RESULT_OK,intent);
        finish();
        //DlgLocation.super.onBackPressed();
    }


}