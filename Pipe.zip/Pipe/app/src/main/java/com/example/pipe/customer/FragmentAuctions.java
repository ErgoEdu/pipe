package com.example.pipe.customer;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pipe.R;
import com.example.pipe.data.DBGeneralData;
import com.example.pipe.data.dataViewAuction;
import com.example.pipe.data.rowViewAuction;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

/**
 * A fragment representing a list of Items.
 */
public class FragmentAuctions extends Fragment {

    // TODO: Customize parameter argument names
    private static final String ARG_COLUMN_COUNT = "column-count";
    // TODO: Customize parameters
    private int mColumnCount = 1;

    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    AuctionsRecyclerViewAdapter adapter; //Egonzalez: adapter of Auctions recycleview
    ArrayList<rowViewAuction> list; //array where be stored the results of viewcervice
    dataViewAuction data;  //data from database, management of querys and php service to get data from app database
    private DBGeneralData generalData; //general data loaded when login to app
    RecyclerView recyclerView;
    public FragmentAuctions() {
    }

    // TODO: Customize parameter initialization
    @SuppressWarnings("unused")
    public static FragmentAuctions newInstance(int columnCount) {
        FragmentAuctions fragment = new FragmentAuctions();
        Bundle args = new Bundle();
        args.putInt(ARG_COLUMN_COUNT, columnCount);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_auctions_list, container, false);

        // Set the adapter
        if (view instanceof RecyclerView) {
            Context context = view.getContext();
            recyclerView = (RecyclerView) view;

            //Egonzalez: set adapter, FILL-UP DATA
            generalData = DBGeneralData.getInstance();
            //Call getOpenAuctions, where is show all my auctions

            if (generalData.getCustomerAuctions()) {
                list = generalData.list_auctions;  //set and  fill up with data of database,
            }
            //FILL-UP DATA endend
            //Egonzalez: set adapter
            adapter = new AuctionsRecyclerViewAdapter(list);  //set the  values o list to adapter contructor
            recyclerView.setAdapter(adapter);
            //Set Layout manager to position the items
            recyclerView.setLayoutManager(new LinearLayoutManager(context));

        }

        return view;
    }

    public void  AddAuction()
    {
        //Toast.makeText(getContext(), "Hizo click", Toast.LENGTH_LONG).show();
        mStartDlgAddAuction.launch(3);  //ejecutes routine to Laucher Dialog
    }

    public class PickAuction extends ActivityResultContract<Integer,rowViewAuction>{

        @NonNull
        @NotNull
        @Override
        public Intent createIntent(@NonNull @NotNull Context context, Integer input) {
            Intent intent = new Intent(context, DlgAddAuction.class);
            intent.putExtra("EXTRA_INT", input);

            return intent;
        }

        @Override
        public rowViewAuction parseResult(int resultCode, @Nullable @org.jetbrains.annotations.Nullable Intent intent) {
            if (resultCode != Activity.RESULT_OK || intent == null) {
                return null;
            }
            return intent.getParcelableExtra("viewauction");  //Get Data name or class from Intent
        }
    }

    //Load DlgAddAuction intent

    private final ActivityResultLauncher<Integer> mStartDlgAddAuction =
            registerForActivityResult( new PickAuction(),
                    new ActivityResultCallback<rowViewAuction>() {

                        @Override
                        public void onActivityResult(rowViewAuction result) {
                            if (result != null)
                            {
                                int n = adapter.getItemCount();
                                list.add(result);
                                int i = list.size();
                                if ( i>0) adapter.notifyItemInserted(i-1);
                                recyclerView.scrollToPosition(adapter.getItemCount() -1);
                               // adapter.notifyDataSetChanged();

                            }

                        }

                    });
}