package com.example.pipe.customer;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pipe.R;
import com.example.pipe.data.DBGeneralData;
import com.example.pipe.data.rowViewService;

import java.util.ArrayList;

/**
 * A fragment representing a list of Items.
 */
public class FragmentServices extends Fragment implements  ServicesRecyclerViewAdapter.ServicesItemClickListener{

    // TODO: Customize parameter argument names
    private static final String ARG_COLUMN_COUNT = "column-count";
    // TODO: Customize parameters
    private int mColumnCount = 1;

    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    ServicesRecyclerViewAdapter adapter; //Egonzalez: adapter of Services recycleview
    ArrayList<rowViewService> list; //array where be stored the results of viewcervice
    private DBGeneralData generaldata;

    public FragmentServices() {
    }

    // TODO: Customize parameter initialization
    @SuppressWarnings("unused")
    public static FragmentServices newInstance(int columnCount) {
        FragmentServices fragment = new FragmentServices();
        Bundle args = new Bundle();
        args.putInt(ARG_COLUMN_COUNT, columnCount);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_services_list, container, false);
        RecyclerView r;
        r=(RecyclerView) view.findViewById(R.id.list);
        // Set the adapter
        if (r instanceof RecyclerView) {  //30 if (view instanceof RecyclerView) {
            //30Context context = view.getContext();
            Context context  =r.getContext();
           //30 RecyclerView recyclerView = (RecyclerView) view;
            // Egonzalez: set adapter
            generaldata = DBGeneralData.getInstance();  // Get General Data class singleton of App
            // Call getOpenServices, where is show all my services
            if (generaldata.getCustomerServices()){
                list =generaldata.list_services; // get the fill-up array of my services
            }
            // Egonzalez: Set adapter
            adapter = new ServicesRecyclerViewAdapter(list, this);  //set the  values o list to adapter contructor
            r.setAdapter(adapter);  //set the local adapter to reciclerview
            // set Layout manager to position the items
            r.setLayoutManager(new LinearLayoutManager(context));
        }
        return view;
    }
    // do click in an button to open Map in a item from ServicesRecyclerViewAdapter
    @Override
    public void onImgButtonMap(int position) {
        rowViewService row = list.get(position);
        // find the position of transport and open coordinates
        if (row != null) {
            // Code from stackoverflow
            double lat = -11.9266081;
            double lng = -77.0550137;
            String labelLocation = "Transporte";
           // String uri = String.format(Locale.ENGLISH, "http://maps.google.com/maps?daddr=%f,%f (%s)", lat, lon, "Where the party is at");
          //  String uri = "http://maps.google.com/maps?q="+ lat  +"," + lon +"("+ labelLocation + ")&iwloc=A&hl=es";
           // String uri = "http://maps.google.com/maps?q=loc:" + lat + "," + lng + " (" + "Label which you want" + ")";

            String uri = String.format("geo:0,0?q=%f,%f (%s)", lat, lng, labelLocation);
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
            intent.setPackage("com.google.android.apps.maps");
            try
            {
                startActivity(intent);
            }
            catch(ActivityNotFoundException ex)
            {
                try
                {
                    Intent unrestrictedIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                    startActivity(unrestrictedIntent);
                }
                catch(ActivityNotFoundException innerEx)
                {
                    Toast.makeText(getContext(), "Please install a maps application", Toast.LENGTH_LONG).show();
                }
            }
            // Code stackoverflow
        }

    }
    // do click in an button to open chat in a item from ServicesRecyclerViewAdapter
    @Override
    public void onImgButtonChat(int position) {
        //Open dialog chat with the class instance from rowViewService
        rowViewService row = list.get(position);

        if (row != null){
            //Open Intent to open whatsapp
           String phone = row.getTransporter_contact();
           if (phone.equals("") || phone == null) return;
            //Begin WhatsApp Code
            String number = phone.contains("+") ? phone : "+51" + phone; // set default number for Peru
            String mensaje = "Deseo coordinar con usted el transporte pendiente";
          /*  Uri uri = Uri.parse("smsto:" + number);
            Intent i = new Intent(Intent.ACTION_SENDTO, uri);
            i.setPackage("com.whatsapp");
            String msg = "Deseo coordinar con usted el transporte pendiente";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=" + number + "&text=" + msg)));
            // End WhatsApp Code
            */
           //Code Copied from
            try{

                    String url = "https://api.whatsapp.com/send?phone="+ number +"&text=" + mensaje;
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    this.startActivity(i);

            }catch(Exception e) {
                Log.e("ERROR WHATSAPP",e.toString());
                Toast.makeText(getActivity(), "No tiene whatsapp instalado!",Toast.LENGTH_SHORT).show();
            }
        }

    }
}