package com.example.pipe.customer;

import android.graphics.Color;
import android.location.Address;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pipe.R;
import com.google.android.gms.maps.GoogleMap;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

//Adapter for the RecyclerView: @+id/dlglocation_list

public class LocationsAdapter
        extends RecyclerView.Adapter<LocationsAdapter.ViewHolder> {
    // Store a member variable for set de locations return by google
    private List<Address> mAddress;
    private GoogleMap mMap;
    private ListItemClickListener listener;
    private final ArrayList<Integer> selected = new ArrayList<>(); //temporal

    //Constructor LocationsAdapter
    public LocationsAdapter(List<Address> addressList, ListItemClickListener listener){
            mAddress = addressList;
            this.listener = listener;
    }




    //EGonzalez: add interface ListItemClickListener to call back to DlgLocation
    public interface ListItemClickListener{
        //Egonzalez: Listener when a function is called send to Parent
        void onImgItemView (int position); // when img_item_view the on location_item.xml is clicked
        void onTvItemAddress (int position); // when tv_item_address the on location_item.xml is clicked

    }

    @NonNull
    @NotNull
    @Override
    //inflates a layout from XML and returning the holder
    public ViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        //Inflate the custom layout
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.location_item, parent, false); //location_item
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull ViewHolder holder, int position) {
        Address mLocation = mAddress.get(position);

        String direccion="";
        int i = mLocation.getMaxAddressLineIndex();
        direccion = mLocation.getAddressLine(i);
        holder.tv_item_address.setText(direccion);

        if (!selected.contains(position)){
            // view not selected
            holder.tv_item_address.setBackgroundColor(Color.LTGRAY);
        }
        else
            // view is selected
            holder.tv_item_address.setBackgroundColor(Color.CYAN);


    }



    //returns the total count of items in tle list mAddress
    @Override
    public int getItemCount() {


        return mAddress.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener
    {
        public final View mView;
        public final TextView tv_item_address;
        public final ImageView img_item_view;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            tv_item_address = (TextView) view.findViewById(R.id.tv_item_address);
            img_item_view = (ImageView) view.findViewById(R.id.img_item_view);
            tv_item_address.setOnClickListener(this);  //Assign a listener to the TextView
            img_item_view.setOnClickListener(this);  //Assign a listener to the image on item img_item_view


        }
        @Override
        public String toString() {
            return super.toString() + " '" + tv_item_address.getText() + "'";
        }

        @Override
        public void onClick(View view) {
                int position = getAdapterPosition(); //position of the item clicked
            if (view == img_item_view) //Imagen img_item_view was clicked
            {
                listener.onImgItemView(position);
            }
            if (view == tv_item_address)
            {
                    view.setBackgroundColor(Color.CYAN);

                // (*1)
                // forcing single selection here...
                if (selected.isEmpty()){
                    selected.add(position); // (done - see note)
                }else {
                    int oldSelected = selected.get(0);
                    selected.clear(); // (*1)... and here.
                    selected.add(position);
                    // note: We do not notify that an item has been selected
                    // because that work is done here.  We instead send
                    // notifications for items which have been deselected.
                    notifyItemChanged(oldSelected);
                }
                listener.onTvItemAddress(position);

            }


        }
    }



}
