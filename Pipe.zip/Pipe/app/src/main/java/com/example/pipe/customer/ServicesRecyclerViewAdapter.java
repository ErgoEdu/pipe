package com.example.pipe.customer;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.pipe.R;
import com.example.pipe.data.DBGeneralData;
import com.example.pipe.data.rowViewService;
import com.example.pipe.customer.PlaceholderContent.PlaceholderItem;

import java.util.List;

/**
 * {@link RecyclerView.Adapter} that can display a {@link PlaceholderItem}.
 * TODO: Replace the implementation with code for your data type.
 */
public class ServicesRecyclerViewAdapter
        extends RecyclerView.Adapter<ServicesRecyclerViewAdapter.ViewHolder> {
    private DBGeneralData generalData;
    private final List<rowViewService> mValues;
    private ServicesItemClickListener listener;

    public ServicesRecyclerViewAdapter(List<rowViewService> items , ServicesItemClickListener listener)
    {
        mValues = items;
        this.listener = listener; // set the listener from fragment to this
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

      //  return new ViewHolder(FragmentServicesBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_services, parent, false); //location_item
        generalData = DBGeneralData.getInstance();
        return new ViewHolder(view);
    }

    // Egonzalez: Interface ServicesItemClickListener, when do a click in some element of the recyclerview
    public interface  ServicesItemClickListener{
        // Functions of the interfaces
        void onImgButtonMap (int position);
        void onImgButtonChat (int position);
    }
    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {

        rowViewService row = mValues.get(position); //Row of array base class in the RecyclerView
        holder.tv_location_begin.setText(row.getLocation_begin_name());
        holder.tv_location_end.setText(row.getLocation_end_name());
        holder.tv_product.setText(row.getProduct_name());
        holder.tv_quantity.setText(Integer.toString(row.getQuantity()));
        String status = row.getStatus();
        String statusName = generalData.getStatusName(status);
        holder.tv_status.setText(statusName);
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener
    {

        public final View mView;
        public final TextView tv_location_begin;
        public final TextView tv_location_end;
        public final TextView tv_product;
        public final TextView tv_quantity;
        public final TextView tv_status;
        public final ImageView img_map;
        public final ImageView img_chat;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            tv_location_begin
                    = (TextView) view.findViewById(R.id.lv_location_begin);
            tv_location_end
                    = (TextView) view.findViewById(R.id.lv_location_end);
            tv_product
                    = (TextView) view.findViewById(R.id.lv_product);
            tv_quantity
                    = (TextView) view.findViewById(R.id.lv_quantity);

            tv_status
                    = (TextView) view.findViewById(R.id.lv_status);
            img_map
                    = (ImageView) view.findViewById(R.id.lv_button);
            img_chat
                    = (ImageView) view.findViewById(R.id.lv_whatsapp);

            img_map.setOnClickListener(this);
            img_chat.setOnClickListener(this);


        }

        @Override
        public String toString() {
            return super.toString() + " '" + tv_location_end.getText() + "'";
        }

        @Override
        public void onClick(View view) {
            int position = getAdapterPosition();
            if (view == img_chat)  // do click in lv_whatsapp
            {
                listener.onImgButtonChat(position);
            }
            if (view == img_map) // do click in lv_button
            {
                listener.onImgButtonMap(position);
            }
         }

    }
}