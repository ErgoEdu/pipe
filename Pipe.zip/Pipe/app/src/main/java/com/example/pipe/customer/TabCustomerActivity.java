package com.example.pipe.customer;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.example.pipe.R;
import com.example.pipe.databinding.ActivityTabCustomerBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;

public class TabCustomerActivity extends AppCompatActivity {

    private ActivityTabCustomerBinding binding;
    //implements function to show DlgAddAuction activity
    SectionsPagerAdapter m_sectionsPagerAdapter;
    private Fragment fragment;  //egonzalez fragment active
    FragmentAuctions fragmentauctions; //egonzalez
    private ViewPager viewPager; //egonzalez

    protected void ShowAddAuction()
    {
       /* Invoque the function AddAuction inside FragmentAuctions to open DlgAddAuction intent;*/

       // fragment=(Fragment) Objects.requireNonNull(viewPager.getAdapter()).instantiateItem(viewPager,0);
       fragment = m_sectionsPagerAdapter.getActiveFragment(viewPager,1);
        if (fragment instanceof FragmentAuctions) {
            fragmentauctions = (FragmentAuctions) fragment;
            fragmentauctions.AddAuction();
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

     //   binding = ActivityTabCustomerBinding.inflate(getLayoutInflater());
        setContentView(R.layout.activity_tab_customer);

      //  SectionsPagerAdapter sectionsPagerAdapter = new
        //        SectionsPagerAdapter(this, getSupportFragmentManager());
        m_sectionsPagerAdapter = new
                SectionsPagerAdapter(this, getSupportFragmentManager());


//        ViewPager viewPager = binding.viewPager;
        viewPager = findViewById(R.id.view_pager);
//        viewPager.setAdapter(sectionsPagerAdapter);
        viewPager.setAdapter(m_sectionsPagerAdapter);

        //TabLayout tabs = binding.tabs;
        TabLayout tabs = findViewById(R.id.tabs);
        tabs.setupWithViewPager(viewPager);

        FloatingActionButton fab  =(FloatingActionButton) findViewById(R.id.fab);// ;binding.fab;

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();*/
                ShowAddAuction(); //Show DlgAddAuction activity
            }
        });
    }
}