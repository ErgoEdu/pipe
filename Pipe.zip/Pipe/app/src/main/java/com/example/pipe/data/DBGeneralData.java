package com.example.pipe.data;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.widget.Toast;

import com.example.pipe.carrier_manager.rowBid;
import com.example.pipe.dataViewBids;
import com.example.pipe.thread.TaskManager;

import java.util.ArrayList;
import java.util.concurrent.Future;

/*
DBGeneralData: Singleton class that stores principal matrix data from database, it fills when log in App
Common data to fill spinners, matrix, from databases

 */
public class DBGeneralData {
    public Locations  m_locations;
    public Products m_products;
    private String people_id; //variable where is stored the people_id indentificator , relative to the user people id
    private boolean bEndLoadData = false;
    private static DBGeneralData  single_instance= null;
    public  ArrayList<rowViewAuction> list_auctions; //array where be stored the results of viewAuctions, auctions
    public  ArrayList<rowViewService> list_services; //array where be stored the results of viewService, service
    public  ArrayList<rowViewService> list_pendings; //array where be stored the results of viewService, service

    public ArrayList<rowBid> list_mybids; //array where stored the result of my current bids, from tabla bids

    RowLocation getLocation (int location_id){
        String sWhere = "id = " + location_id;
        Locations location = new Locations("id,address, lat_coord,long_coord ", "locations", sWhere);
        RowLocation row;
        Future future = TaskManager.getTaskManager().forBackgroundTasks().submit(location);

        while (!future.isDone() )
        {

        }
        if (location.locationsList.size()  > 0)
        {
            row = location.locationsList.get(0);
            return  row;
        }
        return null;
    }

    /*  public double latitude = 0.0f;  //Use for google maps, latitude value
        public double longitude = 0.0f;  //Use for google maps, longitude value
        public String marker  = "";  // marker for google maps location*/
    //Constructor for DBGeneralData
    // Preferences root
    private static final String PREFS_USER ="PREFSUSER" ;  //Key to user preferences


    private DBGeneralData()
    {
        m_locations = new Locations("id,address, lat_coord,long_coord ", "locations", "location_type in ('P' ,'T')");
        m_products = new Products(" * "," products "," type_product in ('D','N') order by cname ");
        list_auctions = new ArrayList<rowViewAuction>();


    }

    // Save user and password in preferences
    public void saveUserPreferences(Context c, String login, String  pwd){

        SharedPreferences prefs = c.getSharedPreferences(PREFS_USER, 0);  //Context.MODE_PRIVATE
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("username", login);
        editor.putString("password", pwd);
        editor.commit();
    }
    // Get Login to the app saved in preferences
    public String getLogin(Context c)
    {
        SharedPreferences prefs = c.getSharedPreferences(PREFS_USER, 0);

        return prefs.getString("username", "");

    }
    // Get Password to the app saved in preferences
    public String getPwd(Context c)
    {
        SharedPreferences prefs = c.getSharedPreferences(PREFS_USER, 0);
        return prefs.getString("password", "");
    }
    //getMyBids: Function to obtain all my bids according to my user: people_id_customer
    public boolean getMyBids()
    {

        dataViewBids data = new dataViewBids();
        String sWhere ;
        sWhere = " people_id = '" + getPeople_id() + "' and status = 'B' " ; //set the filter from the dataViewAuction
        data.setWhere(sWhere);
        data.pre_columns = " auction_id, high_price "; // all the columns of bids to see
        Future future = TaskManager.getTaskManager().forLightWeightBackgroundTasks().submit(data);

        while (!future.isDone() )
        {

        }
        list_mybids = data.list; //set the array of auctions
        return true;

    }

    //getCustomerAuctions: Function to obtain all auctions with status ='O' and make for people_id_customer, my user

    public boolean getCustomerAuctions()
    {

        dataViewAuction data = new dataViewAuction();
        String sWhere ;
        sWhere = " people_id_customer = '" + getPeople_id() + "' and status = 'O' " ; //set the filter from the dataViewAuction
        data.setWhere(sWhere);
        data.pre_columns = " * "; // all the columns of view_auctions
        Future future = TaskManager.getTaskManager().forLightWeightBackgroundTasks().submit(data);

        while (!future.isDone() )
        {

        }
        list_auctions = data.list; //set the array of auctions
        return true;

    }

    // getCustomerServices(): open services actives from table service
    public boolean getCustomerServices()
    {

        dataViewService data = new dataViewService();
        String sWhere ;
        sWhere = " people_id_customer = '" + getPeople_id() + "' and status <> 'F' " ; //set the filter from the viewServices, different to F, finalized
        data.setWhere(sWhere);
        data.pre_columns = " * "; // all the columns of view_auctions
        try {
            Future<Integer> future = TaskManager.getTaskManager().forLightWeightBackgroundTasks().submit(data);

            if (future.get().intValue() == 1) {

            }
            list_services = data.list; //set the array of auctions
            return true;
        }
        catch (Exception e) {
            list_services = data.list; //set the array of auctions
            return false;
        }


    }
    // end getCustomerServices()

    //begin getPendingServices(): function to get data from DB, from viewService, pendings to transport by me
    public boolean getPendingServices()
    {

        dataViewService data = new dataViewService();
        String sWhere ;
        sWhere = " people_id_carrier = '" + getPeople_id() + "' and status <> 'F' " ; //set the filter from the viewServices, different to F, finalized
        data.setWhere(sWhere);
        data.pre_columns = " * "; // all the columns of view_auctions
        try {
            Future<Integer> future = TaskManager.getTaskManager().forLightWeightBackgroundTasks().submit(data);

            if (future.get().intValue() == 1) {

              //  return true;
            }
            list_pendings = data.list; //set the array of auctions
            return true;
        }
        catch (Exception e) {
            list_pendings = data.list; //set the array of auctions
            return false;
        }


    }
    //end getPendingServices()


    //getOpenAuctions: Function to obtain all auctions with status ='O'
    public boolean getOpenAuctions()
    {

        dataViewAuction data = new dataViewAuction();
        String sWhere ;
        sWhere = " status = 'O' " ; //set the filter from the dataViewAuction
        data.setWhere(sWhere);
        data.pre_columns = " * "; // all the columns of view_auctions
        Future future = TaskManager.getTaskManager().forLightWeightBackgroundTasks().submit(data);

        while (!future.isDone() )
        {

        }
        list_auctions = data.list; //set the array of auctions
        return true;

    }

    public boolean LoadData()
    {
        //Run code to fill up class Locations with Location data
        //TaskManager.getTaskManager().forLightWeightBackgroundTasks().execute(m_locations);
        Future future = TaskManager.getTaskManager().forBackgroundTasks().submit(m_locations);

        while (!future.isDone() )
        {

        }

//        TaskManager.getTaskManager().forLightWeightBackgroundTasks().execute(m_products);
        Future future2 = TaskManager.getTaskManager().forBackgroundTasks().submit(m_products);

        while (!future2.isDone() )
        {

        }
        return  true;
    }
    // Static method
    // Static method to create instance of Singleton class
    public static DBGeneralData getInstance()
    {
        if (single_instance == null)
            single_instance = new DBGeneralData();

        return single_instance;
    }
    //Begin getStatusName: get the status name based in flag status of table service
    public String getStatusName(String status)
    {
        switch (status)
        {
            case "A":
                return "Asignado";
            case "B":
                return "En camino al punto de despacho.";
            case "C":
                return "En punto de despacho.";
            case "D":
                return "En Camino al destino.";
            case "E":
                return "En punto de destino";
            case "F":
                return "Operacion finalizada";
            default:
                return "No definido";
        }

    }
    //End getStatusName
    //Begin getStatusNext: get the next status of service
    public String getStatusNext(String status)
    {
        switch (status)
        {
            case "A":
                return "B";
            case "B":
                return "C";
            case "C":
                return "D";
            case "D":
                return "E";
            case "E":
                return "F";
            default:
                return "N";
        }

    }
    //End getStatusNext
    // Open map with coordinates
    public void openMap(Context c, double latBegin, double lngBegin, double latEnd, double lngEnd){
        String marker = " Destino";
        String uri = String.format("http://maps.google.com/maps?saddr=%f,%f&daddr=%f,%f (%s)",latBegin, lngBegin,latEnd,lngEnd, marker) ;
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
        intent.setPackage("com.google.android.apps.maps");
        try
        {
            c.startActivity(intent);
        }
        catch(ActivityNotFoundException ex)
        {
            try
            {
                Intent unrestrictedIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                c.startActivity(unrestrictedIntent);
            }
            catch(ActivityNotFoundException innerEx)
            {
                Toast.makeText(c, "Please install a maps application", Toast.LENGTH_LONG).show();
            }
        }
    }
    public void openMap(Context c, double lat, double lng){
        String marker = " Destino";
        //String uri = String.format("http://maps.google.com/maps?saddr=%f,%f&daddr=%f,%f (%s)",location_from.latitude, location_from.longitude,location_to.latitude,location_to.longitude, marker) ;
        String uri = "http://maps.google.com/maps?q=loc:" + lat + "," + lng+ " (" + "Destino" + ")";

        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
        intent.setPackage("com.google.android.apps.maps");
        try
        {
            c.startActivity(intent);
        }
        catch(ActivityNotFoundException ex)
        {
            try
            {
                Intent unrestrictedIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                c.startActivity(unrestrictedIntent);
            }
            catch(ActivityNotFoundException innerEx)
            {
                Toast.makeText(c, "Please install a maps application", Toast.LENGTH_LONG).show();
            }
        }
    }
    // End Open Map
    public boolean openMapLocation(Context c, int location_begin, int location_end) {
        double latBegin=0.0f;
        double lngBegin=0.0f;
        double latEnd = 0.0f;
        double lngEnd = 0.0f;
        if (location_begin > 0) {
            RowLocation row_begin = getLocation(location_begin);
            if (row_begin != null) {
                latBegin = row_begin.getLat_coord();
                lngBegin = row_begin.getLong_coord();
            }
        }
        RowLocation row_end = getLocation(location_end);
        if (row_end != null) {
            latEnd = row_end.getLat_coord();
            lngEnd = row_end.getLong_coord();
        }
        if (location_begin > 0) {
            openMap(c, latBegin, lngBegin, latEnd, lngEnd);
        } else {
            openMap(c, latEnd, lngEnd);
        }
        return true;
    }




    public String getPeople_id() {
        return people_id;
    }

    public void setPeople_id(String people_id) {
        this.people_id = people_id;
    }
}
