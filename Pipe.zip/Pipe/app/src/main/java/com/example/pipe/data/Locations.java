package com.example.pipe.data;

import com.example.pipe.thread.GetSimpleDataDBTask;

import java.util.ArrayList;

public class Locations extends GetSimpleDataDBTask {
    public ArrayList<RowLocation> locationsList = new ArrayList<>();  //Array of RowLocation class
    RowLocation clase;
    public Locations(String sColumns, String sTable, String sWhere) {
        super(sColumns, sTable, sWhere);
    }

    @Override
    public void GetRow(int rowPosition, String keyName, String keyValue) {
          if (clase!=null)
          {
              clase.GetRow(rowPosition,keyName, keyValue);
          }
    }

    @Override
    public void BeginRow() {
        clase = new RowLocation();  //created an instance of class
    }

    @Override
    public void EndRow() {
        locationsList.add(clase);
    }
}
