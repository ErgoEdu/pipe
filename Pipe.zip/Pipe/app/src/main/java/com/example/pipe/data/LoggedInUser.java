package com.example.pipe.data;

/**
 * Data class that captures user information for logged in users retrieved from LoginRepository
 */
public class LoggedInUser {

    private String userId;
//    private String displayName;
    private String userLevel;
    private String appTypeAccess;
    private String userName;
    private String password;
    private String people_id;

    public LoggedInUser(String userId, String userLevel, String appTypeAccess, String userName, String password,String people_id) {
        this.userId = userId;
        this.userLevel = userLevel;
        this.appTypeAccess = appTypeAccess;
        this.userName = userName;
        this.password = password;
        this.people_id = people_id;
    }

    public String getUserId() {
        return userId;
    }

    public String getUserLevel() {
        return userLevel;
    }
    public String getAppTypeAccess() { return appTypeAccess;}
    public String getDisplayName(){ return userName;}
    public String getPassword(){ return password; }
    public String getPeople_id() {
        return people_id;
    }
}