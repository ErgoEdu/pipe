package com.example.pipe.data;

import com.example.pipe.thread.LoginUserTask;
import com.example.pipe.thread.TaskManager;

import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.Future;

/**
 * Class that handles authentication w/ login credentials and retrieves user information.
 */
public class LoginDataSource {

    JSONObject json = null;
    String sResponse = "";
    String UserLevel = "";
    String AppTypeAccess = "";
    String UserName = "";
    String people_id = ""; //people_id for session
    boolean bUserAuthorized = false;

    public Result<LoggedInUser> login(String userId, String password) {

        // Get Instance of General Data (where common variables are stored)
        DBGeneralData generaldata = DBGeneralData.getInstance();
        LoginUserTask loginusertask = new LoginUserTask();
        loginusertask.setDbPhpFile("init_pipe_session.php");
        loginusertask.setLogin(userId);
        loginusertask.setPwd(password);
        // Run Connection to DB
        try {
            Future<Integer> future = TaskManager.getTaskManager().forLightWeightBackgroundTasks().submit(loginusertask);
         // if result valid login
         if (future.get().intValue() == 1) {
                UserLevel = loginusertask.getUser_level();
                AppTypeAccess = loginusertask.getApp_type_access();
                UserName = loginusertask.getCname();
                people_id = loginusertask.getPeople_id();
                generaldata.LoadData();
                LoggedInUser fakeUser =
                        new LoggedInUser(userId, UserLevel, AppTypeAccess, UserName, password, people_id);
                return new Result.Success<>(fakeUser);
            } else {
                return new Result.Error(new IOException("Error logging in"));
            }
        }
        catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }

    public void logout() {
        // TODO: revoke authentication
    }
}