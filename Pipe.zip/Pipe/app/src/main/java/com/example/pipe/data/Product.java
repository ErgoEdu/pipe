package com.example.pipe.data;

import androidx.annotation.Nullable;

import org.jetbrains.annotations.NotNull;

public class Product {
    public int id;
    public String cname;
    public String type_unit;
    public String type_product;
    public double density;

    public Product(){
        this.id = 0;
        this.type_unit = "";
        this.type_product = "";
        this.density = 0.0f;
    }

    public void SetRowValue(String keyName, String keyValue)
    {
        switch (keyName)
        {
            case "id":
                this.id = Integer.parseInt(keyValue);
                break;
            case "cname":
                this.cname = keyValue;
                break;
            case "type_unit":
                this.type_unit = keyValue;
                break;
            case "type_product":
                this.type_product = keyValue;
                break;
            case "density":
                this.density= Double.parseDouble(keyValue);
                break;

        }

    }

    //to display object as a String
    @NotNull

    @Override
    public String toString() {
        // return super.toString();
        return cname;
    }

    @Override
    public boolean equals(@Nullable @org.jetbrains.annotations.Nullable Object obj) {
        //return super.equals(obj);
        if (obj instanceof Product) {
            Product c = (Product) obj;
            if (c.cname.equals(cname) && c.id == id);
            return true;
        }
        return false;
    }
}
