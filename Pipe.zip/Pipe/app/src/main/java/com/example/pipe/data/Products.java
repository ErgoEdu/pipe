package com.example.pipe.data;

import com.example.pipe.thread.GetSimpleDataDBTask;

import java.util.ArrayList;

public class Products extends GetSimpleDataDBTask {
    public ArrayList<Product> datos = new ArrayList<>();  //Array of Product class
     Product clase;  // clase: instance of Product
    public Products(String sColumns, String sTable, String sWhere) {
        super(sColumns, sTable, sWhere);
    }

    @Override
    public void GetRow(int rowPosition, String keyName, String keyValue) {
        if (clase!=null)
        {
            clase.SetRowValue(keyName, keyValue);
        }
    }

    @Override
    public void BeginRow() {
        clase = new Product();
    }

    @Override
    public void EndRow() {
        datos.add(clase);
    }
}
