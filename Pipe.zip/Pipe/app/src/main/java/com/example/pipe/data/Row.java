package com.example.pipe.data;

//Base Class of Any Row

public abstract class Row {

    public Row(){

        }

    public abstract void SetRowValue(String keyName, String keyValue);

}
