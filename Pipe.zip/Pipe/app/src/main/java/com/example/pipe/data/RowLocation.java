package com.example.pipe.data;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.Nullable;

import com.example.pipe.thread.DBTask;

import org.jetbrains.annotations.NotNull;

public class RowLocation extends DBTask implements Parcelable {

    protected int id;
    protected String address;
    protected double lat_coord;
    protected double long_coord;
    protected String ubigeo_id;
    protected String location_type;

    private String postalcode;
    private String subadminarea;
    private String sublocality;
    private String adminarea;


    public RowLocation(int id, String address, double lat_coord, double long_coord, String ubigeo_id, String location_type) {
       super();

        this.id = id;
        this.address = address;
        this.lat_coord = lat_coord;
        this.long_coord = long_coord;
        this.ubigeo_id = ubigeo_id;
        this.location_type = location_type;

    }


    //main constructor
    public RowLocation()
    {

        super();
        this.id = 0;
        this.address = "";
        this.lat_coord = 0.0f;
        this.long_coord = 0.0f;
        this.ubigeo_id = "000000";
        this.location_type = "U";

    }

    protected RowLocation(Parcel in) {
        id = in.readInt();
        address = in.readString();
        lat_coord = in.readDouble();
        long_coord = in.readDouble();
        ubigeo_id = in.readString();
        location_type = in.readString();
        postalcode = in.readString();
        subadminarea = in.readString();
        sublocality = in.readString();
        adminarea = in.readString();
    }

    public static final Creator<RowLocation> CREATOR = new Creator<RowLocation>() {
        @Override
        public RowLocation createFromParcel(Parcel in) {
            return new RowLocation(in);
        }

        @Override
        public RowLocation[] newArray(int size) {
            return new RowLocation[size];
        }
    };

    @Override
    public void GetRow(int rowPosition, String keyName, String keyValue) {
        switch (keyName)
        {
            case "id":
                this.id = Integer.parseInt(keyValue);
                break;
            case "address":
                this.address = keyValue;
                break;
            case "lat_coord":
                this.lat_coord = Double.parseDouble(keyValue);
                break;
            case "long_coord":
                this.long_coord = Double.parseDouble(keyValue);
                break;
            case "ubigeo_id":
                this.ubigeo_id = keyValue;
                break;
            case "location_type":
                this.location_type = keyValue;
                break;
            case "postalcode":
                this.postalcode = keyValue;
                break;
            case "subadminarea":
                this.subadminarea = keyValue;
                break;
            case "sublocality":
                this.sublocality= keyValue;
                break;
            case "adminarea":
                this.adminarea = keyValue;
                break;
        }   }

    @Override
    public void BeginRow() {

    }

    @Override
    public void EndRow() {

    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        addParam("id", id);
        this.id = id;
    }



    public String getAddress() {

        return address;
    }

    public void setAddress(String address) {
        addParam("address", address);
        this.address = address;
    }

    public double getLat_coord() {
        return lat_coord;
    }

    public void setLat_coord(double lat_coord) {
        addParam("lat_coord",lat_coord);
        this.lat_coord = lat_coord;
    }

    public double getLong_coord() {
        return long_coord;
    }

    public void setLong_coord(double long_coord) {
        addParam("long_coord",long_coord);
        this.long_coord = long_coord;
    }

    public String getUbigeo_id() {
        return ubigeo_id;
    }

    public void setUbigeo_id(String ubigeo_id) {
        addParam("ubigeo_id", ubigeo_id);
        this.ubigeo_id = ubigeo_id;
    }

    public String getLocation_type() {
        return location_type;
    }

    public void setLocation_type(String location_type) {
        addParam("location_type", location_type);
        this.location_type = location_type;
    }

    //to display object as a String
    @NotNull

    @Override
    public String toString() {
        // return super.toString();
        return address;
    }

    @Override
    public boolean equals(@Nullable @org.jetbrains.annotations.Nullable Object obj) {
        //return super.equals(obj);
        if (obj instanceof RowLocation) {
            RowLocation c = (RowLocation) obj;
            if (c.getId() == id);
            return true;
        }
        return false;
    }



    public String getPostalcode() {
        return postalcode;
    }

    public void setPostalcode(String postalcode) {
        addParam("postalcode",postalcode);
        this.postalcode = postalcode;
    }

    public String getSubadminarea() {
        return subadminarea;
    }

    public void setSubadminarea(String subadminarea) {
        addParam("subadminarea",subadminarea);
        this.subadminarea = subadminarea;
    }

    public String getSublocality() {
        return sublocality;
    }

    public void setSublocality(String sublocality) {
        addParam("sublocality", sublocality);
        this.sublocality = sublocality;
    }

    public String getAdminarea() {
        return adminarea;
    }

    public void setAdminarea(String adminarea) {
        addParam("adminarea", adminarea);
        this.adminarea = adminarea;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(id);
        parcel.writeString(address);
        parcel.writeDouble(lat_coord);
        parcel.writeDouble(long_coord);
        parcel.writeString(ubigeo_id);
        parcel.writeString(location_type);
        parcel.writeString(postalcode);
        parcel.writeString(subadminarea);
        parcel.writeString(sublocality);
        parcel.writeString(adminarea);
    }



}
