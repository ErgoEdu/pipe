package com.example.pipe.data;

import com.example.pipe.thread.DBTask;

import java.util.ArrayList;

public class dataViewAuction extends DBTask {
//    public ArrayList<rowViewAuction> list = new ArrayList<rowViewAuction>();  //Array of Row type class
    public ArrayList<rowViewAuction> list;
    private rowViewAuction row;  //row class

    //Main constructor
    public dataViewAuction()
    {
        super();
         list = new ArrayList<rowViewAuction>();
        setPhpConfig("view_auctions",4);  //SELECT view, sTable=view_auctions, operationtype=4 for select
    }


    @Override
    public void GetRow(int rowPosition, String keyName, String keyValue) {
        if (row!=null)
        {
            row.GetRow(rowPosition,keyName,keyValue);
        }
    }

    @Override
    public void BeginRow() {
        //create new class, for every new row in the view results
        row = new rowViewAuction();

    }

    @Override
    public void EndRow() {
        list.add(row);  // with the las field in the row, add new element to the Array

    }


}
