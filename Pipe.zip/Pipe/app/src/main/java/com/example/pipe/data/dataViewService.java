package com.example.pipe.data;

import com.example.pipe.thread.DBCTask;

import java.util.ArrayList;

public class dataViewService extends DBCTask {
    public ArrayList<rowViewService> list;
    private rowViewService row;  //row class

    //main constructor
    public dataViewService()
    {
        super();
        list = new ArrayList<rowViewService>();
        setPhpConfig("view_services",4);  //SELECT view, sTable=view_auctions, operationtype=4 for select
    }

    @Override
    public void GetRow(int rowPosition, String keyName, String keyValue) {
        if (row!=null)
        {
            row.GetRow(rowPosition,keyName,keyValue);
        }
    }

    @Override
    public void BeginRow() {
        //create new class, for every new row in the view results
        row = new rowViewService();
    }

    @Override
    public void EndRow() {
        list.add(row);  // with the las field in the row, add new element to the Array
    }
}
