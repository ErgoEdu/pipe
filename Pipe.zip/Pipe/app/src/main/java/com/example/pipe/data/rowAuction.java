package com.example.pipe.data;
/* Egonzalez Class rowAuction
to accessing row data from table Auctions */

import androidx.annotation.Nullable;

import com.example.pipe.thread.DBTask;
import com.example.pipe.thread.DBTaskParameter;

import java.util.Date;

public class rowAuction extends DBTask {
    //main constructor


    private int id;
    private String description;
    private Date auction_date;
    private Date close_date;
    private Date date_limit_transport;
    private float real_sell_price;
    private float max_sell_price;
    private String people_id_winner;
    private String comments;
    private int people_id_customer;
    private int qualification;

    public rowAuction() {
        super();
    }




    @Override
    public String toString() {
        // return super.toString();
        return getDescription();
    }

    @Override
    public boolean equals(@Nullable @org.jetbrains.annotations.Nullable Object obj) {
        //return super.equals(obj);
        if (obj instanceof rowAuction) {
            rowAuction c = (rowAuction) obj;
           if (c.getId() == getId());
            return true;
        }
        return false;
    }

    @Override
    public void EndRow() {

    }


    @Override
    public void GetRow(int rowPosition, String keyName, String keyValue) {

        switch (keyName)
        {
            case "id":
                this.id = Integer.parseInt(keyValue);
                break;
            case "description":
                this.description = keyValue;
                break;
            case "auction_date":
                this.auction_date = getDateFromStr(keyValue);
                break;
            case "close_date":
                this.close_date = getDateFromStr(keyValue);
                break;
            case "date_limit_transport":
                this.date_limit_transport = getDateFromStr(keyValue);
                break;
            case "real_sell_price":
                this.real_sell_price = Float.parseFloat(keyValue);
                break;
            case "max_sell_price":
            this.max_sell_price = Float.parseFloat(keyValue);
            break;

            case "people_id_winner":
                this.people_id_winner = keyValue;
            break;
            case "comments":
                this.comments = keyValue;
            break;
            case "people_id_customer":
                this.people_id_customer =Integer.parseInt(keyValue);
            break;
            case "qualification":
                this.qualification =Integer.parseInt(keyValue);
            break;
        }
    }

    @Override
    public void BeginRow() {

    }



    public Date getAuction_date() {
        return auction_date;
    }

    public void setAuction_date(Date auction_date) {
        DBTaskParameter parameter = new DBTaskParameter("auction_date", auction_date);
        addParam(parameter);

        this.auction_date = auction_date;
    }

    public Date getClose_date() {
        return close_date;
    }

    public void setClose_date(Date close_date) {
        DBTaskParameter parameter = new DBTaskParameter("close_date",close_date);
        addParam(parameter);

        this.close_date = close_date;
    }

    public Date getDate_limit_transport() {
        return date_limit_transport;
    }

    public void setDate_limit_transport(Date date_limit_transport) {
        DBTaskParameter parameter = new DBTaskParameter("date_limit_transport",date_limit_transport);
        addParam(parameter);

        this.date_limit_transport = date_limit_transport;
    }

    public float getReal_sell_price() {

        return real_sell_price;
    }

    public void setReal_sell_price(float real_sell_price) {
        DBTaskParameter parameter = new DBTaskParameter("real_sell_price",real_sell_price);
        addParam(parameter);
        this.real_sell_price = real_sell_price;
    }

    public float getMax_sell_price() {

        return max_sell_price;
    }

    public void setMax_sell_price(float max_sell_price) {
        DBTaskParameter parameter = new DBTaskParameter("max_sell_price",max_sell_price);
        addParam(parameter);
        this.max_sell_price = max_sell_price;
    }

    public String getPeople_id_winner() {
        return people_id_winner;
    }

    public void setPeople_id_winner(String people_id_winner) {
        DBTaskParameter parameter = new DBTaskParameter("people_id_winner", people_id_winner);
        addParam(parameter);
        this.people_id_winner = people_id_winner;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        DBTaskParameter parameter = new DBTaskParameter("comments", comments);
        addParam(parameter);
        this.comments = comments;
    }

    public int getPeople_id_customer() {
        return people_id_customer;
    }

    public void setPeople_id_customer(int people_id_customer) {
        DBTaskParameter parameter = new DBTaskParameter("people_id_customer",people_id_customer );
        addParam(parameter);
        this.people_id_customer = people_id_customer;
    }

    public int getQualification() {
        return qualification;
    }

    public void setQualification(int qualification) {
        DBTaskParameter parameter = new DBTaskParameter("qualification",qualification);
        addParam(parameter);
        this.qualification = qualification;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        DBTaskParameter parameter = new DBTaskParameter("id",id);
        addParam(parameter);
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        DBTaskParameter parameter = new DBTaskParameter("description",description);
        addParam(parameter);
        this.description = description;
    }


}
