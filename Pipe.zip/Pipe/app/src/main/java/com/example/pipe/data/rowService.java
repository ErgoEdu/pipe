package com.example.pipe.data;
/* Egonzalez Class rowService
to accessing row data from table Services */

import androidx.annotation.Nullable;

import org.jetbrains.annotations.NotNull;

public class rowService {
    int id;
    String location_end;
    public rowService()
    {


    }

    //to display object as a String
    @NotNull

    @Override
    public String toString() {
        // return super.toString();
        return location_end;
    }

    @Override
    public boolean equals(@Nullable @org.jetbrains.annotations.Nullable Object obj) {
        //return super.equals(obj);
        if (obj instanceof rowService) {
            rowService c = (rowService) obj;
            if (c.id == id);
            return true;
        }
        return false;
    }
}
