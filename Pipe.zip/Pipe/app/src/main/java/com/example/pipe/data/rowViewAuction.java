package com.example.pipe.data;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.Nullable;

import com.example.pipe.thread.DBTask;

import org.jetbrains.annotations.NotNull;

import java.util.Date;

/* Egonzalez Class rowViewService
to accessing row data from DB: View=viewauctions */
public class rowViewAuction extends DBTask implements Parcelable {
    protected int id;
    protected int location_begin;
    protected String location_begin_name;
    protected int location_end;
    protected String location_end_name;
    protected int product;
    protected String product_name;
    protected int quantity;
    protected Date date_limit_transport;
    protected String description;
    protected String comments;
    protected String people_id_customer;
    protected boolean withbid = false; //Already have a bid by the user, no in database directly
    protected float high_price = 0.0f; //If participate in an auction, the high_price offert. not in database directly

    public boolean isWithbid() {
        return withbid;
    }

    public void setWithbid(boolean withbid) {
        this.withbid = withbid;
    }

    public float getHighprice() {
        return high_price;
    }

    public void setHighPrice(float high_price) {
        this.high_price = high_price;
    }



    //main constructor
    public rowViewAuction()
    {
        super();
        withbid = false;
    }

    public rowViewAuction(Parcel in) {

        id = in.readInt();
        location_begin = in.readInt();
        location_begin_name = in.readString();
        location_end = in.readInt();
        location_end_name = in.readString();
        product = in.readInt();
        product_name = in.readString();
        quantity = in.readInt();
        description = in.readString();
        comments = in.readString();
        people_id_customer = in.readString();
        date_limit_transport = getDateFromStr(in.readString());
    }


    public static final Creator<rowViewAuction> CREATOR = new Creator<rowViewAuction>() {
        @Override
        public rowViewAuction createFromParcel(Parcel in) {
            return new rowViewAuction(in);
        }

        @Override
        public rowViewAuction[] newArray(int size) {
            return new rowViewAuction[size];
        }
    };

    //to display object as a String
    @NotNull

    @Override
    public String toString() {
        // return super.toString();
        return location_end_name;
    }

    @Override
    public boolean equals(@Nullable @org.jetbrains.annotations.Nullable Object obj) {
        //return super.equals(obj);
        if (obj instanceof rowViewAuction) {
           rowViewAuction c = (rowViewAuction) obj;
            if (c.id == id);
            return true;
        }
        return false;
    }


    @Override
    public void GetRow(int rowPosition, String keyName, String keyValue) {
        switch (keyName)
        {
            case "id":
                id = Integer.parseInt(keyValue);
                break;
            case "location_begin":
                location_begin = Integer.parseInt(keyValue);
                break;
            case "location_begin_name":
                location_begin_name = keyValue;
                break;
            case "location_end":
                location_end = Integer.parseInt(keyValue);
                break;
            case "location_end_name":
                location_end_name = keyValue;
                break;
            case "product_id":
                this.product = Integer.parseInt(keyValue);
                break;
            case "product_name":
                this.product_name = keyValue;
                break;
            case "quantity":
                this.quantity = Integer.parseInt(keyValue);
                break;
            case "date_limit_transport":
                this.date_limit_transport = getDateFromStr(keyValue);
                break;
            case "description":
                this.description= keyValue;
            case "comments":
                this.comments= keyValue;
                break;
            case "people_id_customer":
                this.people_id_customer = keyValue;
                break;
        }
    }

    @Override
    public void BeginRow() {

    }

    @Override
    public void EndRow() {

    }



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getLocation_begin() {
        return location_begin;
    }

    public void setLocation_begin(int location_begin) {
        addParam("location_begin", location_begin);
        this.location_begin = location_begin;
    }

    public int getLocation_end() {
        return location_end;
    }

    public void setLocation_end(int location_end) {
        addParam("location_end", location_end);
        this.location_end = location_end;
    }

    public int getProduct() {
        return product;
    }

    public void setProduct(int product) {
        addParam("product_id", product);
        this.product = product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        addParam("quantity", quantity);
        this.quantity = quantity;
    }

    public String getDate_limit_trasport() {
        return getStrFromDate(date_limit_transport);
    }

    public void setDate_limit_transport(Date date_limit_transport) {
        addParam("date_limit_transport", date_limit_transport);
        this.date_limit_transport = date_limit_transport;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {

        addParam("description", description);
        this.description = description;
    }

    public String getLocation_begin_name() {
        return location_begin_name;
    }

    public void setLocation_begin_name(String location_begin_name) {
        this.location_begin_name = location_begin_name;
    }

    public String getLocation_end_name() {
        return location_end_name;
    }

    public void setLocation_end_name(String location_end_name) {
        this.location_end_name = location_end_name;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        addParam("comments", comments);
        this.comments = comments;
    }

    public String getPeople_id_customer() {

        return people_id_customer;
    }

    public void setPeople_id_customer(String people_id_customer) {
        addParam("people_id_customer", people_id_customer);
        this.people_id_customer = people_id_customer;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(id);
        parcel.writeInt(location_begin);
        parcel.writeString(location_begin_name);
        parcel.writeInt(location_end);
        parcel.writeString(location_end_name);
        parcel.writeInt(product);
        parcel.writeString(product_name);
        parcel.writeInt(quantity);
        parcel.writeString(description);
        parcel.writeString(comments);
        parcel.writeString(people_id_customer);
        parcel.writeString(getStrFromDate(date_limit_transport));

    }
}
