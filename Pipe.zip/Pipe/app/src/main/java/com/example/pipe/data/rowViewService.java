package com.example.pipe.data;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.Nullable;

import com.example.pipe.thread.DBCTask;

import org.jetbrains.annotations.NotNull;

/* Egonzalez Class rowViewService
to accessing row data from DB: View=viewservices */
public class rowViewService extends DBCTask implements Parcelable {

    // Generic Fields in Service
    protected int id;
    protected int location_begin;
    protected String location_begin_name;
    protected int location_end;
    protected String location_end_name;
    protected int product;
    protected String product_name;
    protected int quantity;
    // Specific Fields in Service
    protected String people_id_customer;
    protected String people_id_carrier;
    protected String status;
    protected String transporter_contact; //cellphone number, generally the user id of people_id_carrier

    public String getCustomer_contact() {
        return customer_contact;
    }

    public void setCustomer_contact(String customer_contact) {
        this.customer_contact = customer_contact;
    }

    protected String customer_contact; //cellphon customer numer, generally the user id of customer, equials phone of people_id_customer

    protected rowViewService(Parcel in) {
        id = in.readInt();
        location_begin = in.readInt();
        location_begin_name = in.readString();
        location_end = in.readInt();
        location_end_name = in.readString();
        product = in.readInt();
        product_name = in.readString();
        quantity = in.readInt();
        people_id_customer = in.readString();
        people_id_carrier = in.readString();
        status = in.readString();
        transporter_contact = in.readString();
        customer_contact = in.readString();
    }

    public static final Creator<rowViewService> CREATOR = new Creator<rowViewService>() {
        @Override
        public rowViewService createFromParcel(Parcel in) {
            return new rowViewService(in);
        }

        @Override
        public rowViewService[] newArray(int size) {
            return new rowViewService[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getLocation_begin() {
        return location_begin;
    }

    public void setLocation_begin(int location_begin) {
        this.location_begin = location_begin;
    }

    public String getLocation_begin_name() {
        return location_begin_name;
    }

    public void setLocation_begin_name(String location_begin_name) {
        this.location_begin_name = location_begin_name;
    }

    public int getLocation_end() {
        return location_end;
    }

    public void setLocation_end(int location_end) {
        this.location_end = location_end;
    }

    public String getLocation_end_name() {
        return location_end_name;
    }

    public void setLocation_end_name(String location_end_name) {
        this.location_end_name = location_end_name;
    }

    public int getProduct() {
        return product;
    }

    public void setProduct(int product) {
        this.product = product;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getPeople_id_customer() {
        return people_id_customer;
    }

    public void setPeople_id_customer(String people_id_customer) {
        this.people_id_customer = people_id_customer;
    }

    public String getPeople_id_carrier() {
        return people_id_carrier;
    }

    public void setPeople_id_carrier(String people_id_carrier) {
        this.people_id_carrier = people_id_carrier;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {


        this.status = status;
    }

    public String getTransporter_contact() {
        return transporter_contact;
    }

    public void setTransporter_contact(String transporter_contact) {
        this.transporter_contact = transporter_contact;
    }


    //Main constructor
    public rowViewService(){
        super();
    }

    @Override
    public void GetRow(int rowPosition, String keyName, String keyValue) {
        switch (keyName)
        {
            case "id":
                id = Integer.parseInt(keyValue);
                break;
            case "location_begin":
                location_begin = Integer.parseInt(keyValue);
                break;
            case "location_begin_name":
                location_begin_name = keyValue;
                break;
            case "location_end":
                location_end = Integer.parseInt(keyValue);
                break;
            case "location_end_name":
                location_end_name = keyValue;
                break;
            case "product_id":
                this.product = Integer.parseInt(keyValue);
                break;
            case "product_name":
                this.product_name = keyValue;
                break;
            case "quantity":
                this.quantity = Integer.parseInt(keyValue);
                break;
            case "people_id_customer":
                this.people_id_customer = keyValue;
                break;
            case "people_id_carrier":
                this.people_id_carrier= keyValue;
            case "status":
                this.status= keyValue;
                break;
            case "phone_carrier":
                this.transporter_contact = keyValue;
                break;
            case "phone_customer":
                this.customer_contact = keyValue;
                break;
        }
    }

    @Override
    public void BeginRow() {

    }

    @Override
    public void EndRow() {

    }

    //to display object as a String
    @NotNull

    @Override
    public String toString() {
        // return super.toString();
        return location_end_name;
    }

    @Override
    public boolean equals(@Nullable @org.jetbrains.annotations.Nullable Object obj) {
        //return super.equals(obj);
        if (obj instanceof rowViewService) {
            rowViewService c = (rowViewService) obj;
            if (c.id == id);
            return true;
        }
        return false;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(id);
        parcel.writeInt(location_begin);
        parcel.writeString(location_begin_name);
        parcel.writeInt(location_end);
        parcel.writeString(location_end_name);
        parcel.writeInt(product);
        parcel.writeString(product_name);
        parcel.writeInt(quantity);
        parcel.writeString(people_id_customer);
        parcel.writeString(people_id_carrier);
        parcel.writeString(status);
        parcel.writeString(transporter_contact);
        parcel.writeString(customer_contact);
    }
}
