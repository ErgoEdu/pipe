package com.example.pipe;

import com.example.pipe.carrier_manager.rowBid;
import com.example.pipe.thread.DBTask;

import java.util.ArrayList;

public class dataViewBids extends DBTask {

   //private variables
    public ArrayList<rowBid> list;
    private rowBid row;  //row class

    //Main constructor
    public dataViewBids()
    {
        super();
        list = new ArrayList<rowBid>();
        setPhpConfig(" bids ",4);  //SELECT view, sTable=view_auctions, operationtype=4 for select
    }


    @Override
    public void GetRow(int rowPosition, String keyName, String keyValue) {
        if (row!=null)
        {
            row.GetRow(rowPosition,keyName,keyValue);
        }

    }

    @Override
    public void BeginRow() {
        row = new rowBid();

    }

    @Override
    public void EndRow() {
        list.add(row);  // with the las field in the row, add new element to the Array

    }
}
