package com.example.pipe.thread;
//principal class to access to database
// Implements class to connect to DB of App, execute operations, return results

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.Callable;
//Enum the types operation to do with DBTask


public abstract class DBCTask implements Callable<Integer> {

    protected ArrayList<DBTaskParameter> mParams; //Array of parameter to acces json query
    private String dbPhpFile;
    private String sTable;
    private String sWhere;
    private int dbNumRecords;
    private int dbNumFields;
    private int operationType=0; // operationType INSERT=1; UPDATE=2, DELETE = 3, SELECT = 4, Stored procedure=5;
    protected DBTaskInterface listener; //variable to save interface
    public String pre_columns = ""; //build param to JSON to pass columns names
    public String pre_values = ""; //build param to JSON to pass column values

    public String getMessage() {
        return Message;
    }

    public void setMessage(String Message) {
        this.Message = Message;
    }

    private String Message;  // Error message from RequestHandler

    public boolean isResults() {
        return results;
    }

    private void setResults(boolean results) {
        this.results = results;
    }

    public boolean results;
    // Main constructor
    public DBCTask ()
    {
        setTable("");
        setWhere("");
        setDbPhpFile("execute_sql.php");  //predeterminate php to execute SQL DB operations
        this.dbNumRecords = 0;
        this.dbNumFields = 0;
        setResults(false);
        mParams = new ArrayList<DBTaskParameter>(); //Instantiate ArrayList mParams
    }
    /*First method to call previous to invoke Runnable classes, method Run,
    String dbPhpFile: a .php file in the server, where make the consults,
    String dbPhpReply: inside the dbPhpFile, is the response name
    * */
    public void setPhpConfig(String sTable, int operationType)
    {
        setTable(sTable);  //table, view, stored procedure name
        setOperationType(operationType);
        /*
           operationType =
           otINSERT=1, otUPDATE=2, otDELETE=3,otSELECT=4, otStored procedure=5;
}
         */

    }

    //add param to array mParams to JSON for send to dbPhpFile
    protected void addParam(DBTaskParameter param){
        mParams.add(param); //add param to array mParams
    }
    //addParam type int to array mParams
    protected void addParam(String paramName,int paramValue){
        DBTaskParameter parameter = new DBTaskParameter(paramName,paramValue);
        mParams.add(parameter); //add param to array mParams
    }



    //addParam type Date to array mParams
    protected void addParam(String paramName,Date paramValue){
        DBTaskParameter parameter = new DBTaskParameter(paramName,paramValue);
        mParams.add(parameter); //add param to array mParams
    }

    //addParam type String to array mParams
    protected void addParam(String paramName,String paramValue){
        DBTaskParameter parameter = new DBTaskParameter(paramName,paramValue);
        mParams.add(parameter); //add param to array mParams
    }


    //addParam type String to array mParams and force to be formatted as numeric
    protected void addParam(String paramName,String paramValue, boolean forceFormatNumeric){
        DBTaskParameter parameter = new DBTaskParameter(paramName,paramValue,forceFormatNumeric);
        mParams.add(parameter); //add param to array mParams
    }
    //addParam type double to array mParams
    protected void addParam(String paramName,double paramValue){
        DBTaskParameter parameter = new DBTaskParameter(paramName,paramValue);
        mParams.add(parameter); //add param to array mParams
    }
    //addParam type float to array mParams
    protected void addParam(String paramName,float paramValue){
        DBTaskParameter parameter = new DBTaskParameter(paramName,paramValue);
        mParams.add(parameter); //add param to array mParams
    }



    //return the number of records returned by DB, consult or insert
    public  int  GetDBNumRecords()
    {
        return dbNumRecords;
    }

    //return the number of fields returns by DB, consult or insert
    public int GetDBNumFields()
    {
        return dbNumFields;
    }

    //set a field value from date in app to string to pass to json
    protected String getStrFromDate(Date date)
    {
        if (date == null) return "";
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        String str = dateFormat.format(date);
        return str;

    }

    //get a param from json php script, to date value in App
    protected Date getDateFromStr(String str)
    {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        Date date = null;
        try {
            date = dateFormat.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;

    }





    //ABSTRACT METHODS
    //  public abstract void GetRow(int rowPosition, String keyName, String keyValue);
    public abstract void GetRow(int rowPosition, String keyName, String keyValue);
    public abstract void BeginRow();  //Called when first row is laaded
    public abstract void EndRow();   //Called when last row is loaded
    //ABSTRACT METHOD for interface
   /* public abstract void NoResults();  //abstract class invocqued when no results in the request
    public abstract void DBTaskEnded(); //Called when the task query was ended
    public abstract void DBTaskInitiated();  //Called when the task query is initiated
*/
  /*  @Override

*/
    public String getDbPhpFile() {
        return dbPhpFile;
    }

    public void setDbPhpFile(String dbPhpFile) {
        this.dbPhpFile = dbPhpFile;
        this.operationType = 6; //custom PHP
    }

    public String getWhere() {
        return sWhere;
    }

    public void setWhere(String sWhere) {
        this.sWhere = sWhere;
    }

    public String getTable() {
        return sTable;
    }

    public void setTable(String sTable) {
        this.sTable = sTable;
    }

    public int getOperationType() {
        return operationType;
    }

    public void setOperationType(int operationType) {
        this.operationType = operationType;
    }
    // Begin of function call, request to DB,post and get data
    @Override
    public Integer call() throws Exception {

      //  try {
            // listener.DBTaskInitiated();  //Call a interface method for ini task
            //construct parameters in JSOBObject,
            JSONObject postDataParams = new JSONObject();
            postDataParams.put("table",getTable());  //the database table
            postDataParams.put("operation_type",getOperationType()); //the operation type, insert=1,update =2, select =4
//            String pre_columns = ""; //build param to JSON to pass columns names
            //          String pre_values = ""; //build param to JSON to pass column values
            // through Array mParams build pre_columns and pre_values
            int n = mParams.size();
            DBTaskParameter p;
            //BEGIN INSERT Construct Params: pre_columns and pre_values for INSERT query
            if (getOperationType() == 1) {
                //for (DBTaskParameter p : mParams) {
                for (int i = 0; i < n; i++){
                    if (i != 0)
                    {
                        pre_columns = pre_columns + ",";
                        pre_values = pre_values + ",";
                    }
                    p = mParams.get(i);
                    pre_columns = pre_columns + p.getParamName();
                    pre_values = pre_values + p.getParamValueFormatted();
                }
                postDataParams.put("pre_columns", pre_columns); //set to JSON objet the parameters
                postDataParams.put("pre_values", pre_values); //set to JSON objet the parameters

            }
            //END INSERT Construct Params.
            //BEGIN CASE getOperationType = 2, UPDATE
            if (getOperationType() == 2) {  //Custom statement ,no use general .php: "execute_sql.php"

                postDataParams.put("pre_columns", pre_columns); //set to JSON objet the parameters WHERE
                postDataParams.put("pre_values", getWhere()); //set to JSON objet the parameters WHERE
             }
            //END UPDATE
            //BEGIN CASE getOperationType = 4 , SELECT
            if (getOperationType() == 4) {  //Custom statement ,no use general .php: "execute_sql.php"
                //for (DBTaskParameter p : mParams) {
                postDataParams.put("pre_columns", pre_columns); //set to JSON objet the parameters WHERE
                postDataParams.put("pre_values", getWhere()); //set to JSON objet the parameters WHERE

            }
            //END CASE getOperationType = 4 , SELECT
            //BEGIN STORED PROCEDURE CASE ,getOperationType = 5
            if (getOperationType() == 5) {
                //for (DBTaskParameter p : mParams) {
                for (DBTaskParameter s : mParams){
                    postDataParams.put(s.getParamName(), s.getParamValueFormatted()); //set to JSON objet the parameters
                }
            }
            //END BEGIN STORED PROCEDURE CASE, getOperationType = 5
            //BEGIN CASE getOperationType = 6 , CUSTOM PHP
            if (getOperationType() == 6) {  //Custom statement ,no use general .php: "execute_sql.php"
                //for (DBTaskParameter p : mParams) {
                postDataParams.put("pre_columns", pre_columns); //set to JSON objet the parameters WHERE
                postDataParams.put("pre_values", getWhere()); //set to JSON objet the parameters WHERE
                // Set the other parameters if they are requires in php
                for (DBTaskParameter s : mParams){
                    postDataParams.put(s.getParamName(), s.getParamValueFormatted()); //set to JSON objet the parameters
                }
            }
            //END CASE getOperationType = 6 , CUSTOM PHP
            String sResponse = RequestHandler.sendPostToURL(dbPhpFile, postDataParams); //Request of JSON php file
            if (sResponse.contains("&fail&:")) {
                // listener.NoResults(); //interface method when is no records as result
                setResults(false); // no results in the consult
                setMessage(sResponse);
                return 0;
            }
            if (sResponse.contains("&good&:")) {
            // listener.NoResults(); //interface method when is no records as result
                setResults(true); // no results in the consult
                setMessage(sResponse);
                return 1;
            }
            JSONObject json = new JSONObject(sResponse);
            JSONArray jArray = json.getJSONArray("data_pipe"); //Array reply from php file
            dbNumRecords = jArray.length(); //num of records reply
            setResults(true); // some results from sResponse
            for (int i = 0; i < dbNumRecords; i++) //the result is many records
            {
                //Successfully access to APP database
                JSONObject e = jArray.getJSONObject(i);
                JSONArray keys = e.names();  // get column names
                String key = ""; //column name
                String valor = ""; //value of column name
                dbNumFields = keys.length(); //num of Fields from the record
                for (int j = 0; j < dbNumFields; j++) //interacts through keys or columns
                {
                    if (j == 0) BeginRow(); //First Field indicate beginning of row
                    key =keys.getString(j);
                    valor = e.getString(key);
                    if (key != "null" && valor != "null"){
                        GetRow(i,key,valor);
                    }//call to abstract method to the heiress method know what to do
                    if (j == keys.length() -1) EndRow(); //Last Field of the row
                }
            }
            return 1;
            // listener.DBTaskEnded(); //Interface method called when task is done
       /* } catch (Exception e) {
            e.printStackTrace();
            return 0;

        }*/
    }
    // end of function call
    //interface
    public interface DBTaskInterface {
        void NoResults();  //abstract class invoqued when no results in the request
        void DBTaskEnded(); //Called when the task query was ended
        void DBTaskInitiated();  //Called when the task query is initiated
    }

    //Assign an interface if is applicable
    public void setCallBack(DBTaskInterface listener)
    {
        this.listener = listener;

    }

    public DBTaskInterface getCallBack()
    {
        return listener;
    }
}
