package com.example.pipe.thread;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DBTaskParameter {
    private String paramName="";
    private String paramValue="";
    private boolean paramNumeric;
    public DBTaskParameter(String paramName,String paramValue)
    {
        setParamName(paramName);
        setParamValue(paramValue);
        setParamNumeric(false); //Generally for types string or dates the param Value have quotes whet sql is builded, for the numeric fiels no quotes are required

    }
    // Force the parameter to no be string but formatted as numeric
    public DBTaskParameter(String paramName,String paramValue, boolean forceFormatNumeric)
    {
        setParamName(paramName);
        setParamValue(paramValue);
        setParamNumeric(forceFormatNumeric); //Generally for types string or dates the param Value have quotes whet sql is builded, for the numeric fiels no quotes are required

    }

    public DBTaskParameter(String paramName,int paramValue)
    {
        setParamName(paramName);
        setParamValue(Integer.toString(paramValue));
        setParamNumeric(true); //Generally for types string or dates the param Value have quotes whet sql is builded, for the numeric fiels no quotes are required

    }
    public DBTaskParameter(String paramName, Date paramValue)
    {
        setParamName(paramName);
        setParamValue(getStrFromDate(paramValue));
        setParamNumeric(false); //Generally for types string or dates the param Value have quotes whet sql is builded, for the numeric fiels no quotes are required

    }
    public DBTaskParameter(String paramName,double paramValue)
    {
        setParamName(paramName);
        setParamValue(Double.toString(paramValue));
        setParamNumeric(true); //Generally for types string or dates the param Value have quotes whet sql is builded, for the numeric fiels no quotes are required

    }
    public DBTaskParameter(String paramName,float paramValue)
    {
        setParamName(paramName);
        setParamValue(Float.toString(paramValue));
        setParamNumeric(true); //Generally for types string or dates the param Value have quotes whet sql is builded, for the numeric fiels no quotes are required

    }

    //set a field value from date in app to string to pass to json
    protected String getStrFromDate(Date date)
    {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        String str = dateFormat.format(date);
        return str;

    }

    public String getParamName() {
        return paramName;
    }

    public void setParamName(String paramName) {
        this.paramName = paramName;
    }

    public String getParamValue() {
        if (paramValue == null) return "";

        return paramValue;
    }

    //return a param Value formatted for SQL
    public String getParamValueFormatted(){
        String valueFormatted = "";
        if (!isParamNumeric()){
            return  "'" + getParamValue() + "'";
        }
        return getParamValue();

    }

    public void setParamValue(String paramValue) {
        this.paramValue = paramValue;
    }

    public boolean isParamNumeric() {
        return paramNumeric;
    }

    protected void setParamNumeric(boolean paramNumeric) {
        this.paramNumeric = paramNumeric;
    }
}
