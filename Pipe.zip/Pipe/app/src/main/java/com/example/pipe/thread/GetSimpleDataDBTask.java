package com.example.pipe.thread;
/*
Egonzalez: 14-DEC-2021
Runnable class to connect to DB and request for simples SQL statments , like to fill up spinners, Dictionary, HashTables
Response of two fields
access to JSON php: get_simple_data_pipe.php (Parameters IN: scolumns, stable, swhere);
 */

import org.json.JSONArray;
import org.json.JSONObject;

public abstract class GetSimpleDataDBTask implements Runnable {

    String sColumns = ""; //Param scolumns for get_simple_data_pipe.php
    String sTable = ""; //Param stable for get_simple_data_pipe.php
    String sWhere = ""; //Param swhere for get_simple_data_pipe.php
    //Constructor of GetSimpleDataDBTask: sColumns(Columns in database for the SQL sentence), STable(Table in database to request), SWhere (SQL WHERE for sql filtering)

    public GetSimpleDataDBTask (String sColumns, String sTable, String sWhere)
    {
        this.sColumns = sColumns;
        this.sTable = sTable;
        this.sWhere = sWhere;

    }
    //abstract method to indicate to pass to the heirness the row values
    public abstract void GetRow(int rowPosition, String keyName, String keyValue);
    public abstract void BeginRow();  //Called when first row is laaded
    public abstract void EndRow();   //Called when last row is loaded

    @Override
    public void run() {
        try {
            //Envia los parametros a la BD mysql,
            JSONObject postDataParams = new JSONObject();
            postDataParams.put("scolumns", sColumns);
            postDataParams.put("stable", sTable);
            postDataParams.put("swhere", sWhere);
            String sResponse = RequestHandler.sendPostToURL("get_simple_data_pipe.php", postDataParams); //Request of JSON php file
            if (sResponse == "fail") return;
            JSONObject json = new JSONObject(sResponse);
            JSONArray jArray = json.getJSONArray("data_pipe"); //Array reply from php file
            for (int i = 0; i < jArray.length(); i++) //the result is many records
            {
                //Successfully access to APP database
                JSONObject e = jArray.getJSONObject(i);
                JSONArray keys = e.names();  // get column names
                String key = ""; //column name
                String valor = ""; //value of column name

                for (int j = 0; j < keys.length(); j++) //interacts through keys or columns
                {
                    if (j == 0) BeginRow(); //First Field indicate beginning of row
                    key =keys.getString(j);
                    valor = e.getString(key);
                    if (key != "null" && valor != "null"){
                        GetRow(i,key,valor);
                    }//call to abstract method to the heiress method know what to do
                    if (j == keys.length() -1) EndRow(); //Last Field of the row
                }


            }

        } catch (Exception e) {
            e.printStackTrace();

        }
    }
}
