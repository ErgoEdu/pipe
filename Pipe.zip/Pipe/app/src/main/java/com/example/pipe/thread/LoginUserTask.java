package com.example.pipe.thread;

//Egonzalez:  13/12/2021
//Class LoginUserTask: Connect to database, to valid credentials to DB

import androidx.annotation.Nullable;

import org.jetbrains.annotations.NotNull;

public class LoginUserTask extends DBCTask {

    private String login;
    private String pwd;
    private String user_level;
    private String people_id;
    private String app_type_access;
    private String status_active_type;
    private String cname;
    boolean UserAuthorized = false;

    //main constructor
    public LoginUserTask() {
        super();

    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        addParam("login", login,true);
        this.login = login;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        addParam("pwd", pwd,true);
        this.pwd = pwd;
    }

    public String getUser_level() {
        return user_level;
    }

    public void setUser_level(String user_level) {
        addParam("user_level",user_level);
        this.user_level = user_level;
    }

    public String getPeople_id() {
        return people_id;
    }

    public void setPeople_id(String people_id) {
        addParam("people_id",people_id, true);
        this.people_id = people_id;
    }

    public String getApp_type_access() {
        return app_type_access;
    }

    public void setApp_type_access(String app_type_access) {
        addParam("app_type_access",app_type_access,true);
        this.app_type_access = app_type_access;
    }

    public String getStatus_active_type() {
        return status_active_type;
    }

    public void setStatus_active_type(String status_active_type) {
        this.status_active_type = status_active_type;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        addParam("cname",cname,true);
        this.cname = cname;
    }

    public boolean isUserAuthorized() {
        return UserAuthorized;
    }

    public void setUserAuthorized(boolean userAuthorized) {
        UserAuthorized = userAuthorized;
    }



    @Override
    public void GetRow(int rowPosition, String keyName, String keyValue) {
        switch (keyName) {
            case "user_level":
                this.user_level = keyValue;
                break;
            case "people_id":
                this.people_id = keyValue;
                break;
            case "cname":
                this.cname = keyValue;
                break;
            case "app_type_access":
                this.app_type_access = keyValue;
                break;
        }
    }

    @Override
    public void BeginRow() {

    }

    @Override
    public void EndRow() {

    }


    //to display object as a String
    @NotNull

    @Override
    public String toString() {
        // return super.toString();
        return cname;
    }

    @Override
    public boolean equals(@Nullable @org.jetbrains.annotations.Nullable Object obj) {
        //return super.equals(obj);
        if (obj instanceof LoginUserTask) {
            LoginUserTask c = (LoginUserTask) obj;
            if (c.getLogin() == login);
            return true;
        }
        return false;
    }
/*

    @Override
    public void run() {
        String msg;
        if (LoginUser()){
            UserAuthorized = true;
            msg = "Usuario autorizado: " + UserId;
        } else{
            UserAuthorized = false;
            msg = "Usuario no autorizado: " + UserId;
        }
*/

}
