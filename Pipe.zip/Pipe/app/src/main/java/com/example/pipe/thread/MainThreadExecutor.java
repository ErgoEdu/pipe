package com.example.pipe.thread;

import android.os.Handler;
import android.os.Looper;

import org.jetbrains.annotations.NotNull;

import java.util.concurrent.Executor;

public class MainThreadExecutor implements Executor {
    private Handler handler = new Handler(Looper.getMainLooper());

    @Override
    public void execute(@NotNull  Runnable runnable) {
        handler.post(runnable);
    }
}
