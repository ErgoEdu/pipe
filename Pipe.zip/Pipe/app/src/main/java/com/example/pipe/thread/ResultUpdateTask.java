package com.example.pipe.thread;
//Class to Update Status Message in Background

import android.widget.TextView;

public class ResultUpdateTask implements Runnable{
   // private TextView message;
    String message;
    private String backgroundMsg;

    public ResultUpdateTask(String msg) {
        message =msg;
    }
    public void setBackgroundMsg(String bmsg) {
        backgroundMsg = bmsg;
    }

    @Override
    public void run() {
        //message.setText(backgroundMsg);
        message = backgroundMsg;
    }
}
