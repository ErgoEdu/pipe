package com.example.pipe.thread;

import android.os.Process;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

//Pipe App: Egonzalez: 12/12/2021
// Class to management of task Asynchronic, class type Singleton
// Management of Database Connection, files, etc

public class TaskManager {
    public static final int NUMBER_OF_CORES = Runtime.getRuntime().availableProcessors();
    private static final int KEEP_ALIVE_TIME = 50;
    //Thread pool executor for background tasks
    private final ThreadPoolExecutor mForBackgroundTasks;//taskThreadPool;
    //Thread pool executor for Light weight background tasks
    private final ThreadPoolExecutor mForLightWeightBackgroundTasks;
    //Thread pool executor for main thread tasks
    private final Executor mMainThreadExecutor;
    //an instance of TaskManager
    private static TaskManager sInstance;

    //returns the instance of TaskManager
    public static TaskManager getInstance(){
        if (sInstance == null){
            synchronized (TaskManager.class){
                sInstance = new TaskManager();
            }
        }
        return sInstance;
    }

    //constructor for TaskManager
    private TaskManager(){
        //setting the thread factory
        ThreadFactory backgroundPriorityThreadFactory = new
                PriorityThreadFactory(Process.THREAD_PRIORITY_BACKGROUND);



        /*taskThreadPool = new ThreadPoolExecutor(NUMBER_OF_THREADS * 2 ,NUMBER_OF_THREADS * 2,
                KEEP_ALIVE_TIME, TimeUnit.MILLISECONDS, taskWorkQueue);*/
        //setting the thread pool executor for mForBackgroundTasks
        mForBackgroundTasks = new ThreadPoolExecutor(
                NUMBER_OF_CORES * 2,
                NUMBER_OF_CORES * 2,
                KEEP_ALIVE_TIME,
                TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<Runnable>(),
                backgroundPriorityThreadFactory
        );
        //setting the thread pool executor for mForLightWeightBackgroundTasks
        mForLightWeightBackgroundTasks = new ThreadPoolExecutor(
                NUMBER_OF_CORES * 4,
                NUMBER_OF_CORES * 4 ,
                KEEP_ALIVE_TIME ,
                TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<Runnable>(),
                backgroundPriorityThreadFactory
        );
        mMainThreadExecutor = new MainThreadExecutor();

    }

    //returns the thread pool executor for background task
    public ThreadPoolExecutor forBackgroundTasks(){
        return mForBackgroundTasks;
    }

    //returns the thread pool executor for light weight background task

    public ThreadPoolExecutor forLightWeightBackgroundTasks(){
        return mForLightWeightBackgroundTasks;
    }

    public Executor forMainThreadTasks(){
        return mMainThreadExecutor;
    }

    public static TaskManager getTaskManager(){
        return getInstance();
    }


    /*public MainThreadExecutor getMainThreadExecutor(){
        return handler;
    }*/
}
