package com.example.pipe.ui.login;

/**
 * Class exposing authenticated user details to the UI.
 */
class LoggedInUserView {
    private String displayName;
    private String appTypeAccess;
    private String password;
    private String UserId;
    private String people_id;
    //... other data fields that may be accessible to the UI

    LoggedInUserView(String displayName, String appTypeAccess,String UserId, String password, String people_id) {
        this.displayName = displayName;
        this.appTypeAccess = appTypeAccess;
        this.UserId = UserId;
        this.password = password;
        this.people_id = people_id;
    }

    String getDisplayName() {
        return displayName;
    }
    String getAppTypeAccess() { return appTypeAccess;}
    String getPassword() { return password;}
    String getUserId()  { return UserId;}
    String getPeople_id() { return people_id;}
}