package com.example.pipe.ui.login;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.pipe.data.DBGeneralData;
import com.example.pipe.databinding.ActivityLoginNewBinding;
import com.example.pipe.thread.LoginUserTask;
import com.example.pipe.thread.TaskManager;

import java.util.concurrent.Future;

public class LoginNewActivity extends AppCompatActivity {

    private ActivityLoginNewBinding binding;
    private LoginViewModel loginViewModel;
    // widgets declaration
    private EditText usernameEditText;
    private EditText passwordEditText;
    private EditText confirmEditText;
    private Button registerButton;
    private ProgressBar loadingProgressBar;
    private RadioButton radioCustomer;
    private RadioButton radioVisit;
    private EditText idEditText;
    private EditText nameEditText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityLoginNewBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        loginViewModel = new ViewModelProvider(this, new LoginViewModelFactory())
                .get(LoginViewModel.class);
        usernameEditText = binding.username;
        passwordEditText = binding.password;
        confirmEditText = binding.confirm;
        registerButton = binding.register;
        loadingProgressBar = binding.loading;
        radioCustomer  = binding.radioCustomer;
        radioVisit = binding.radioVisit;
        idEditText = binding.id;
        nameEditText = binding.name;

        // add form state
        loginViewModel.getLoginNewFormState().observe(this, new Observer<LoginNewFormState>() {
                    @Override
                    public void onChanged(LoginNewFormState loginnewFormState) {
                        if (loginnewFormState == null) {
                            return;
                        }
                        registerButton.setEnabled(loginnewFormState.isDataValid());
                        if (loginnewFormState.getUsernameError() != null) {
                            usernameEditText.setError(getString(loginnewFormState.getUsernameError()));
                        }
                        if (loginnewFormState.getPasswordError() != null) {
                            passwordEditText.setError(getString(loginnewFormState.getPasswordError()));
                        }
                        if (loginnewFormState.getConfirmError() != null) {
                            confirmEditText.setError(getString(loginnewFormState.getConfirmError()));
                        }
                        if (loginnewFormState.getIdError() != null) {
                            idEditText.setError(getString(loginnewFormState.getIdError()));
                        }
                        if (loginnewFormState.getNameError() != null) {
                            nameEditText.setError(getString(loginnewFormState.getNameError()));
                        }


                    }
                });
        // add listeners
        TextWatcher afterTextChangedListener =  new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                loginViewModel.loginNewDataChanged(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString(),
                        confirmEditText.getText().toString(), idEditText.getText().toString(),nameEditText.getText().toString());
            }
        };
        usernameEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.addTextChangedListener(afterTextChangedListener);
        confirmEditText.addTextChangedListener(afterTextChangedListener);
        idEditText.addTextChangedListener(afterTextChangedListener);
        nameEditText.addTextChangedListener(afterTextChangedListener);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SaveUser();

            }
        });


        // Save new User to database

    }
    // Save User to database
    public void SaveUser(){
        // final ProgressBar loadingProgressBar = binding.loading;
        final EditText nameEditText = binding.name;
        // get data from this widgets form
        String login = usernameEditText.getText().toString();
        String pwd = passwordEditText.getText().toString();
        String app_type_access = "C";
        if (radioCustomer.isChecked()) app_type_access ="C";
        if (radioVisit.isChecked()) app_type_access ="V";
        String  people_id = idEditText.getText().toString();
        String cname = nameEditText.getText().toString();
        DBGeneralData generaldata = DBGeneralData.getInstance();
        LoginUserTask loginusertask = new LoginUserTask();
        loginusertask.setDbPhpFile("save_pipe_session.php");
        loginusertask.setLogin(login);
        loginusertask.setPwd(pwd);
        loginusertask.setApp_type_access(app_type_access);
        loginusertask.setPeople_id(people_id);
        loginusertask.setCname(cname);
        // Try to save the new record
        try {
            Future<Integer> future = TaskManager.getTaskManager().forLightWeightBackgroundTasks().submit(loginusertask);
            // if result valid login
            if (future.get().intValue() == 1) {
                //after INSERT data the call the Login Intent
                generaldata.saveUserPreferences(this, login, pwd);
                Class loginActivity = LoginActivity.class;
                Intent startChildActivityIntent = new Intent(this, loginActivity);
                startActivity(startChildActivityIntent);
                finish();  // close this intent
               // Toast.makeText(this,loginusertask.getMessage(), Toast.LENGTH_SHORT).show();

            } else {
                Toast.makeText(this,loginusertask.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        catch (Exception e) {
            Toast.makeText(this,e.getMessage(), Toast.LENGTH_SHORT);
        }
        //End try to save the new record
    }

}