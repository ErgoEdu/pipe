package com.example.pipe.ui.login;

import androidx.annotation.Nullable;

public class LoginNewFormState {
    @Nullable
    private Integer usernameError;
    @Nullable
    private Integer passwordError;
    @Nullable
    private Integer confirmError;
    @Nullable
    private Integer idError;
    @Nullable
    private Integer nameError;
    private boolean isDataValid;

    LoginNewFormState(@Nullable Integer usernameError, @Nullable Integer passwordError, @Nullable Integer confirmError,
                      @Nullable Integer idError, @Nullable Integer nameError) {
        this.usernameError = usernameError;
        this.passwordError = passwordError;
        this.confirmError = confirmError;
        this.idError = idError;
        this.nameError = nameError;
        this.isDataValid = false;
    }

    LoginNewFormState(boolean isDataValid) {
        this.usernameError = null;
        this.passwordError = null;
        this.confirmError = null;
        this.idError = null;
        this.nameError = null;
        this.isDataValid = isDataValid;
    }

    @Nullable
    Integer getUsernameError() {
        return usernameError;
    }

    @Nullable
    Integer getPasswordError() {
        return passwordError;
    }
    @Nullable
    Integer getConfirmError() {
        return confirmError;
    }
    @Nullable
    Integer getIdError() {
        return idError;
    }
    @Nullable
    Integer getNameError() {
        return nameError;
    }
    boolean isDataValid() {
        return isDataValid;
    }
}
