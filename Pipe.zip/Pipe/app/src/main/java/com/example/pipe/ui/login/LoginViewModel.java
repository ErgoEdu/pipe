package com.example.pipe.ui.login;

import android.util.Patterns;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.pipe.R;
import com.example.pipe.data.LoginRepository;
import com.example.pipe.data.Result;
import com.example.pipe.data.LoggedInUser;

public class LoginViewModel extends ViewModel {

    private MutableLiveData<LoginFormState> loginFormState = new MutableLiveData<>();
    private MutableLiveData<LoginNewFormState> loginNewFormState = new MutableLiveData<>();
    private MutableLiveData<LoginResult> loginResult = new MutableLiveData<>();
    private LoginRepository loginRepository;

    LoginViewModel(LoginRepository loginRepository) {
        this.loginRepository = loginRepository;
    }

    LiveData<LoginFormState> getLoginFormState() {
        return loginFormState;
    }

    LiveData<LoginNewFormState> getLoginNewFormState() {
        return loginNewFormState;
    }

    LiveData<LoginResult> getLoginResult() {
        return loginResult;
    }

    public void login(String username, String password) {
        // can be launched in a separate asynchronous job
        Result<LoggedInUser> result = loginRepository.login(username, password);

        if (result instanceof Result.Success) {
            LoggedInUser data = ((Result.Success<LoggedInUser>) result).getData();
            loginResult.setValue(new LoginResult(new LoggedInUserView(data.getDisplayName(), data.getAppTypeAccess(), data.getUserId(),data.getPassword(),data.getPeople_id())));
        } else {
            loginResult.setValue(new LoginResult(R.string.login_failed));
        }
    }

    public void loginDataChanged(String username, String password) {
        if (!isUserNameValid(username)) {
            loginFormState.setValue(new LoginFormState(R.string.invalid_username, null));
        } else if (!isPasswordValid(password)) {
            loginFormState.setValue(new LoginFormState(null, R.string.invalid_password));
        } else {
            loginFormState.setValue(new LoginFormState(true));
        }
    }
    // to valid username, password and confirm inside a LoginNewActivity
    public void loginNewDataChanged(String username, String password, String confirm, String id, String name) {
        if (!isUserNameValid(username)) {
            loginNewFormState.setValue(new LoginNewFormState(R.string.invalid_username, null,null, null, null));
        } else if (!isPasswordValid(password)) {
            loginNewFormState.setValue(new LoginNewFormState(null, R.string.invalid_password,null,null, null));
        } else if (!isConfirmValid(password, confirm)) {
            loginNewFormState.setValue(new LoginNewFormState(null, null, R.string.invalid_confirm, null, null));
        } else if (!isIdValid(id)) {
            loginNewFormState.setValue(new LoginNewFormState(null, null, null, R.string.invalid_id,null));
        } else if (!isNameValid(name)) {
            loginNewFormState.setValue(new LoginNewFormState(null, null, null, null,R.string.invalid_name));
        }
        else {
            loginNewFormState.setValue(new LoginNewFormState(true));
        }
    }

    // A placeholder username validation check
    private boolean isUserNameValid(String username) {
        if (username == null) {
            return false;
        }
       if (username.contains("@")) {
            return Patterns.EMAIL_ADDRESS.matcher(username).matches();
        } else {
           // no contains special characters
           if (username.contains("'")) return false;
           if (username.contains(";")) return false;
           if (username.contains("-")) return false;
           if (username.contains("#")) return false;
           if (username.contains(",")) return false;
           if (username.contains(".")) return false;
           return !username.trim().isEmpty() && username.trim().length() >= 9 && username.trim().length() <=20;
        }


    }

    // A placeholder password validation check
    private boolean isPasswordValid(String password) {
        // no contains special characters
        if (password.contains("'")) return false;
        if (password.contains(";")) return false;
        if (password.contains("-")) return false;
        if (password.contains("#")) return false;
        if (password.contains(",")) return false;
        if (password.contains(".")) return false;
        return password != null && password.trim().length() > 5 && password.trim().length() <=20;
    }
    // A placeholder password and confirm validation check
    private boolean isConfirmValid(String password, String confirm) {
        // password and confirm are equals
        return confirm != null && password.equals(confirm);
    }
    // A placeholder id validation check
    private boolean isIdValid(String id) {
        // id is equal 8 characters
        return !id.trim().isEmpty() && id.trim().length() == 8 && id.matches("[0-9]+");
    }
    // A placeholder password and confirm validation check
    private boolean isNameValid(String name) {
        // name contains only alphabetic characters
        return !name.trim().isEmpty() && name.trim().length() >= 5 && name.matches("[ a-zA-Z]+") && name.trim().length() <= 255;
    }

}